"use strict";
(self["webpackChunkyunweibao_ad"] = self["webpackChunkyunweibao_ad"] || []).push([["src_views_ADAS_vue-src_components_stickyBottom_vue-src_components_tab_vue"],{

/***/ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/ADAS.vue?vue&type=script&setup=true&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/ADAS.vue?vue&type=script&setup=true&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.date.to-string.js */ "./node_modules/core-js/modules/es.date.to-string.js");
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.timers.js */ "./node_modules/core-js/modules/web.timers.js");
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/field/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/button/index.mjs");
/* harmony import */ var _utlis_QueryStr__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/utlis/QueryStr */ "./src/utlis/QueryStr.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vue-router */ "./node_modules/_vue-router@4.1.5@vue-router/dist/vue-router.mjs");
/* harmony import */ var _mixins_index_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../mixins/index.js */ "./src/mixins/index.js");












var _hoisted_1 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_10__.createElementVNode)("label", {
  size: "small",
  type: "primary"
}, "CM", -1);

var _hoisted_2 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_10__.createElementVNode)("label", {
  size: "small",
  type: "primary"
}, "CM", -1);

var _hoisted_3 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_10__.createElementVNode)("label", {
  size: "small",
  type: "primary"
}, "CM", -1);

var _hoisted_4 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_10__.createElementVNode)("label", {
  size: "small",
  type: "primary"
}, "CM", -1);

 // Checkbox





/* harmony default export */ __webpack_exports__["default"] = ({
  __name: 'ADAS',
  setup: function setup(__props) {
    var _mixins = (0,_mixins_index_js__WEBPACK_IMPORTED_MODULE_12__["default"])(),
        t = _mixins.t,
        postAN = _mixins.postAN,
        TabHeaders = _mixins.TabHeaders,
        StickyBottom = _mixins.StickyBottom,
        callJSResult_Status = _mixins.callJSResult_Status;

    var arr = [1, 2, 3, 5];
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_13__.useRoute)();
    var guideRouter = route.query.guide; // 标题

    var navTitle = (0,vue__WEBPACK_IMPORTED_MODULE_10__.ref)(t("adas.navTitle"));
    var guide = (0,vue__WEBPACK_IMPORTED_MODULE_10__.ref)(true);
    var nowCmd = (0,vue__WEBPACK_IMPORTED_MODULE_10__.ref)(""); // 当前使用的指令

    var adasInfo = (0,vue__WEBPACK_IMPORTED_MODULE_10__.ref)([]);
    var loading = (0,vue__WEBPACK_IMPORTED_MODULE_10__.ref)(false);

    var calibrationFn2 = function calibrationFn2() {
      adasInfo.value = sessionStorage.test != undefined ? sessionStorage.test.split(",") : [];
    };

    var calibrationFn = function calibrationFn(num) {
      loading.value = true;

      var cmds = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(adasInfo.value);

      var items = [];

      for (var i = 0; i < cmds.length; i++) {
        if (arr.includes(i)) {
          items.push(cmds[i]);
        }
      }

      var iArr = [items[0], items[1], items[3], items[2]];
      sessionStorage.test = cmds.toString();
      setTimeout(function () {
        loading.value = false;
      }, 2000);
      setTimeout(function () {
        postAN.calibrationFn(num, iArr.join("@"));
      }, 1000);
    };

    var setNumber = function setNumber(num) {
      return num / 10;
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_10__.defineComponent)({
      name: "yunweibao-Demarcate"
    }); // -------------------------------------------------------------------
    // 安卓回调函数

    var callJSResult = function callJSResult(str) {
      var cmds = str.split(";")[0];
      var cmdArr = cmds.split(",").splice(1);
      console.log("返回的参数" + cmdArr);

      if (cmdArr.length < 2) {
        console.log("参数不全 ----" + cmdArr.length);
        calibrationFn2();
        return false;
      }

      for (var i = 0; i < cmdArr.length; i++) {
        if (arr.includes(i)) {
          cmdArr[i] = setNumber(cmdArr[i]);
        }
      } // console.log(cmdArr)


      cmdArr[2] = cmdArr[2] == "" ? 0 : cmdArr[2];
      cmdArr[2] = cmdArr[1] / 2 - cmdArr[2]; // console.warn("操作完成" + cmdArr[3]); // 第四个参数

      adasInfo.value = cmdArr;
    };

    var updateUi = function updateUi(state, cmds) {
      var cmdInfo = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(adasInfo.value);

      if (state == 1) {
        var cmdsArr = cmds.split("@");
        (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_11__.arrIndexExchange)(cmdsArr, 3, 4); // console.log("再次回调" + cmdsArr);
        // console.log(cmdInfo);

        var num = 0;

        for (var i = 0; i < cmdInfo.length; i++) {
          if (arr.includes(i)) {
            adasInfo.value[i] = cmdsArr[num];
            num++;
          }
        }
      }

      console.warn(adasInfo.value.toString()); // console.warn(cmds);
    }; // 向安卓发送指令


    var androidStatus_fn = function androidStatus_fn() {
      var param = ""; // alert(555555)

      if (guideRouter) {
        var guideIndex = sessionStorage.guideIndex;
        guide.value = true;
        var guideArr = JSON.parse(sessionStorage.guide);
        param = guideArr[guideIndex].split("@");
      } else {
        guide.value = false;
        param = (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_11__.getQueryString)("param").split("@"); // 解析出指令
      } // console.log(param);


      nowCmd.value = param[1];
      postAN.ANSend(param[1]); // console.log("222222222222")
    };

    androidStatus_fn();
    (0,vue__WEBPACK_IMPORTED_MODULE_10__.onMounted)(function () {
      window.callJSResult = callJSResult;
      window.callJSResult_Status = callJSResult_Status;
      window.updateUi = updateUi;
    });
    return function (_ctx, _cache) {
      return (0,vue__WEBPACK_IMPORTED_MODULE_10__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_10__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_10__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(TabHeaders), {
        navTitle: navTitle.value,
        leftArrow: false
      }, null, 8, ["navTitle"]), (0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_14__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        },
        "class": "cellGroup"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.Field), {
            label: _ctx.$t('adas.label[0]'),
            placeholder: _ctx.$t('adas.placeholder[0]'),
            type: "number",
            "input-align": "right",
            modelValue: adasInfo.value[1],
            "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
              return adasInfo.value[1] = $event;
            }),
            maxlength: "3"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
              return [_hoisted_1];
            }),
            _: 1
          }, 8, ["label", "placeholder", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_14__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        },
        "class": "cellGroup"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.Field), {
            label: _ctx.$t('adas.label[1]'),
            placeholder: _ctx.$t('adas.placeholder[1]'),
            type: "number",
            "input-align": "right",
            modelValue: adasInfo.value[2],
            "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
              return adasInfo.value[2] = $event;
            }),
            "label-width": "200",
            maxlength: "3"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
              return [_hoisted_2];
            }),
            _: 1
          }, 8, ["label", "placeholder", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_14__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        },
        "class": "cellGroup"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.Field), {
            label: _ctx.$t('adas.label[2]'),
            "label-width": "200",
            placeholder: _ctx.$t('adas.placeholder[2]'),
            type: "number",
            "input-align": "right",
            modelValue: adasInfo.value[5],
            "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
              return adasInfo.value[5] = $event;
            }),
            maxlength: "3"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
              return [_hoisted_3];
            }),
            _: 1
          }, 8, ["label", "placeholder", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_14__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        },
        "class": "cellGroup"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.Field), {
            label: _ctx.$t('adas.label[3]'),
            "label-width": "200",
            placeholder: _ctx.$t('adas.placeholder[3]'),
            type: "number",
            "input-align": "right",
            modelValue: adasInfo.value[3],
            "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
              return adasInfo.value[3] = $event;
            }),
            maxlength: "3"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
              return [_hoisted_4];
            }),
            _: 1
          }, 8, ["label", "placeholder", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_14__.CellGroup), {
        inset: "",
        style: {
          "margin": "20px",
          "height": "40px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.Button), {
            type: "primary",
            style: {
              "width": "100%"
            },
            onClick: _cache[4] || (_cache[4] = function ($event) {
              return calibrationFn(1);
            }),
            loading: loading.value
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_10__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_10__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.toDisplayString)(_ctx.$t("adas.button")), 1)];
            }),
            _: 1
          }, 8, ["loading"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_10__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_10__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_10__.unref)(StickyBottom), {
        guide: guide.value
      }, null, 8, ["guide"]), [[vue__WEBPACK_IMPORTED_MODULE_10__.vShow, guide.value]])], 64);
    };
  }
});

/***/ }),

/***/ "./src/views/ADAS.vue":
/*!****************************!*\
  !*** ./src/views/ADAS.vue ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ADAS_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ADAS.vue?vue&type=script&setup=true&lang=js */ "./src/views/ADAS.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _ADAS_vue_vue_type_style_index_0_id_71bda090_lang_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css */ "./src/views/ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css");



;

const __exports__ = _ADAS_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"];

/* harmony default export */ __webpack_exports__["default"] = (__exports__);

/***/ }),

/***/ "./src/views/ADAS.vue?vue&type=script&setup=true&lang=js":
/*!***************************************************************!*\
  !*** ./src/views/ADAS.vue?vue&type=script&setup=true&lang=js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* reexport safe */ _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_ADAS_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]; }
/* harmony export */ });
/* harmony import */ var _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_ADAS_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-41!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./ADAS.vue?vue&type=script&setup=true&lang=js */ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/ADAS.vue?vue&type=script&setup=true&lang=js");
 

/***/ }),

/***/ "./src/views/ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css":
/*!************************************************************************!*\
  !*** ./src/views/ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_clonedRuleSet_12_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_use_1_node_modules_vue_loader_17_0_0_vue_loader_dist_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_use_2_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_ADAS_vue_vue_type_style_index_0_id_71bda090_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css");


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.includes.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.includes.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $includes = (__webpack_require__(/*! ../internals/array-includes */ "./node_modules/core-js/internals/array-includes.js").includes);
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var addToUnscopables = __webpack_require__(/*! ../internals/add-to-unscopables */ "./node_modules/core-js/internals/add-to-unscopables.js");

// FF99+ bug
var BROKEN_ON_SPARSE = fails(function () {
  return !Array(1).includes();
});

// `Array.prototype.includes` method
// https://tc39.es/ecma262/#sec-array.prototype.includes
$({ target: 'Array', proto: true, forced: BROKEN_ON_SPARSE }, {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables('includes');


/***/ }),

/***/ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/ADAS.vue?vue&type=style&index=0&id=71bda090&lang=css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

}]);
//# sourceMappingURL=src_views_ADAS_vue-src_components_stickyBottom_vue-src_components_tab_vue.4cb69694.js.map