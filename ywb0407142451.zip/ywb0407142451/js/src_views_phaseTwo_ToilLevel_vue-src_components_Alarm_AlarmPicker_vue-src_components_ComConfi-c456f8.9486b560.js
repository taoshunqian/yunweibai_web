"use strict";
(self["webpackChunkyunweibao_ad"] = self["webpackChunkyunweibao_ad"] || []).push([["src_views_phaseTwo_ToilLevel_vue-src_components_Alarm_AlarmPicker_vue-src_components_ComConfi-c456f8"],{

/***/ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/ToilLevel.vue?vue&type=script&setup=true&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/ToilLevel.vue?vue&type=script&setup=true&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.date.to-string.js */ "./node_modules/core-js/modules/es.date.to-string.js");
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_Alarm_AlarmPicker_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/Alarm//AlarmPicker.vue */ "./src/components/Alarm/AlarmPicker.vue");
/* harmony import */ var _components_ComConfig_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/ComConfig.vue */ "./src/components/ComConfig.vue");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/toast/function-call.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/field/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/row/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/col/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/button/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/checkbox/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/popup/index.mjs");
/* harmony import */ var _utlis_QueryStr__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/utlis/QueryStr */ "./src/utlis/QueryStr.js");
/* harmony import */ var _mixins_index_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/mixins/index.js */ "./src/mixins/index.js");











var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_9__.pushScopeId)("data-v-39e3b458"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_9__.popScopeId)(), n;
};

var _hoisted_1 = {
  style: {
    "display": "none"
  }
};

var _hoisted_2 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("span", null, "L", -1);
});

var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("span", null, "L", -1);
});

var _hoisted_4 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("span", null, "%", -1);
});

var _hoisted_5 = {
  style: {
    "margin-top": "20px",
    "background": "#ffffff"
  }
};

var _hoisted_6 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("span", null, "L", -1);
});

var _hoisted_7 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("span", null, "%", -1);
});

var _hoisted_8 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("footer", {
    style: {
      "padding-bottom": "100px"
    }
  }, null, -1);
});



 // Checkbox




/* harmony default export */ __webpack_exports__["default"] = ({
  __name: 'ToilLevel',
  setup: function setup(__props) {
    /*
    报警器 和 刷卡器 共用
    */
    var _mixins = (0,_mixins_index_js__WEBPACK_IMPORTED_MODULE_13__["default"])(),
        t = _mixins.t,
        postAN = _mixins.postAN,
        TabHeaders = _mixins.TabHeaders,
        StickyBottom = _mixins.StickyBottom,
        callJSResult_Status = _mixins.callJSResult_Status;

    var columnsOilType = ["TUB", "N08", "PLUG", "I TALON"];
    var navTitle = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(t('ToilLevel.navTitle')); // const imageStyle = "transform:rotate(90deg);margin-left: 45%;height: 200px;";
    // const imageInfo = ref('../../assets/image/TUB.jpg');

    var addCalibrationInfo = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)([]); // 添加标定信息

    var showPicker = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false); // picker 弹出

    var columns = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)([]); //

    var defaultIndex = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(0);
    var oilCmd = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)([]);

    var BottomSearch = function BottomSearch() {
      // addCalibrationInfo.value = [];
      androidStatus_fn();
    }; // 保存


    var BottomSubmit = function BottomSubmit() {
      var resCmd = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(oilCmd.value);

      var arr = resCmd.splice(0, 7);

      var calibrationArr = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(addCalibrationInfo.value);

      var calibraStr = "";
      var maxNum = 0;

      for (var i = 0; i < calibrationArr.length; i++) {
        var item = [calibrationArr[i].value2, calibrationArr[i].value1].join("*") + ",";
        maxNum += +calibrationArr[i].value1;
        calibraStr += item;
      }

      arr[4] = maxNum;

      if (arr[6] == 0) {
        arr[6] = "";
      }

      arr.push(calibraStr);
      var cmds = arr.toString();
      cmds = "$OILPARAMV3," + cmds;
      console.log(cmds);
      postAN.ANsendSetting(cmds);
    }; // 弹出 picker 选择器


    var showPickerFn = function showPickerFn(num) {
      showPicker.value = true;

      switch (num) {
        case 1:
          // 协议类型
          columns.value = columnsOilType;
          defaultIndex.value = oilCmd.value[0];
          break;
      }
    }; // picker 弹出层确认


    var onConfirm = function onConfirm(items) {
      oilCmd.value[0] = items[1];
      showPicker.value = false;
    }; // 删除


    var deleteCalibrationInfoFn = function deleteCalibrationInfoFn() {
      var arr = addCalibrationInfo.value;
      arr.filter(function (value, index, arr) {
        if (value.check) {
          arr.splice(index, 1);
        }
      });
      oilCmd.value[3] = arr.length;
    }; // 添加


    var addCalibrationInfoFn = function addCalibrationInfoFn() {
      var arr = addCalibrationInfo.value;

      if (arr.length == 20) {
        vant__WEBPACK_IMPORTED_MODULE_14__.Toast.fail(t('ToilLevel.addCalibrationInfoFn'));
        return false;
      }

      arr.push({
        check: false,
        value1: "1",
        value2: "1"
      });
      oilCmd.value[3] = arr.length;
    }; // 一维数组转二维数组


    var toTwoArr = function toTwoArr(arr) {
      var mapArr = [];

      for (var i = 0; i < arr.length; i++) {
        var item = arr[i].split("*");
        mapArr.push({
          check: false,
          value1: (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_12__.keepDecimal)(item[1], 2),
          value2: (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_12__.keepDecimal)(item[0], 2)
        });
      }

      return mapArr;
    }; // 命名空间


    (0,vue__WEBPACK_IMPORTED_MODULE_9__.defineComponent)({
      name: "yunweibao-ToilLevel"
    }); // -------------------------------------------------------------------
    // 安卓回调函数r

    var callJSResult = function callJSResult(str) {
      // alert(cmds)
      var cmds = str.split(";")[0];
      var cmdArr = cmds.split(",").splice(1);
      var calibraArr = cmdArr.splice(9);
      addCalibrationInfo.value = toTwoArr(calibraArr);
      console.warn(cmdArr[0]);
      oilCmd.value = cmdArr;
    }; // 向安卓发送指令


    var androidStatus_fn = function androidStatus_fn() {
      postAN.ANSend("$OILPARAMV3");
    };

    androidStatus_fn();
    (0,vue__WEBPACK_IMPORTED_MODULE_9__.onMounted)(function () {
      window.callJSResult = callJSResult;
      window.callJSResult_Status = callJSResult_Status;
    });
    return function (_ctx, _cache) {
      return (0,vue__WEBPACK_IMPORTED_MODULE_9__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_9__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(TabHeaders), {
        navTitle: navTitle.value,
        leftArrow: false
      }, null, 8, ["navTitle"]), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)(_components_ComConfig_vue__WEBPACK_IMPORTED_MODULE_11__["default"], {
        loadCmdInfo: _ctx.loadCmdInfo,
        status: _ctx.status,
        cmdCmdInfo: _ctx.cmdCmdInfo,
        onComConfirm: _ctx.comConfirm
      }, null, 8, ["loadCmdInfo", "status", "cmdCmdInfo", "onComConfirm"])]), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.Cell), {
            title: _ctx.$t('ToilLevel.template[0]'),
            "is-link": "",
            value: columnsOilType[oilCmd.value[0]],
            onClick: _cache[0] || (_cache[0] = function ($event) {
              return showPickerFn(1);
            })
          }, null, 8, ["title", "value"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
            label: _ctx.$t('ToilLevel.template[1]'),
            modelValue: oilCmd.value[4],
            "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
              return oilCmd.value[4] = $event;
            }),
            "input-align": "right",
            type: "tel",
            disabled: "",
            "label-class": "disabledStyle"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
              return [_hoisted_2];
            }),
            _: 1
          }, 8, ["label", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
            label: _ctx.$t('ToilLevel.template[2]'),
            modelValue: oilCmd.value[8],
            "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
              return oilCmd.value[8] = $event;
            }),
            disabled: "",
            "input-align": "right",
            "label-class": "disabledStyle"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
              return [_hoisted_3];
            }),
            _: 1
          }, 8, ["label", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
            label: _ctx.$t('ToilLevel.template[3]'),
            modelValue: oilCmd.value[7],
            "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
              return oilCmd.value[7] = $event;
            }),
            disabled: "",
            "input-align": "right"
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
              return [_hoisted_4];
            }),
            _: 1
          }, 8, ["label", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
            modelValue: oilCmd.value[5],
            "onUpdate:modelValue": _cache[4] || (_cache[4] = function ($event) {
              return oilCmd.value[5] = $event;
            }),
            label: _ctx.$t('ToilLevel.template[4]'),
            "label-width": "120",
            type: "tel",
            "input-align": "right"
          }, null, 8, ["modelValue", "label"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
            modelValue: oilCmd.value[2],
            "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
              return oilCmd.value[2] = $event;
            }),
            label: _ctx.$t('ToilLevel.template[5]'),
            placeholder: _ctx.$t('ToilLevel.templatePlaceholder[0]'),
            type: "tel",
            "input-align": "right"
          }, null, 8, ["modelValue", "label", "placeholder"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementVNode)("div", _hoisted_5, [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.Row), null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Col), {
            span: "16"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), null, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
                    label: _ctx.$t('ToilLevel.template[6]'),
                    placeholder: _ctx.$t('ToilLevel.templatePlaceholder[1]'),
                    "input-align": "right",
                    modelValue: oilCmd.value[3],
                    "onUpdate:modelValue": _cache[6] || (_cache[6] = function ($event) {
                      return oilCmd.value[3] = $event;
                    }),
                    disabled: ""
                  }, null, 8, ["label", "placeholder", "modelValue"])];
                }),
                _: 1
              })];
            }),
            _: 1
          }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Col), {
            span: "8"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_20__.Button), {
                type: "danger",
                size: "small",
                style: {
                  "margin-right": "10px",
                  "margin-top": "6px",
                  "float": "right"
                },
                onClick: deleteCalibrationInfoFn
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.toDisplayString)(_ctx.$t('ToilLevel.template[7]')), 1)];
                }),
                _: 1
              }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_20__.Button), {
                type: "primary",
                size: "small",
                style: {
                  "float": "right",
                  "margin-top": "6px",
                  "margin-right": "10px"
                },
                onClick: addCalibrationInfoFn
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.toDisplayString)(_ctx.$t('ToilLevel.template[8]')), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          })];
        }),
        _: 1
      })]), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.Row), null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Col), {
            offset: "1",
            span: "22"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
              return [((0,vue__WEBPACK_IMPORTED_MODULE_9__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_9__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_9__.renderList)(addCalibrationInfo.value, function (item, index) {
                return (0,vue__WEBPACK_IMPORTED_MODULE_9__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createBlock)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_15__.CellGroup), {
                  style: {
                    "margin-top": "10px"
                  },
                  key: index
                }, {
                  "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                    return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.Cell), null, {
                      title: (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                        return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Checkbox), {
                          shape: "square",
                          modelValue: item.check,
                          "onUpdate:modelValue": function onUpdateModelValue($event) {
                            return item.check = $event;
                          }
                        }, {
                          "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                            return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.toDisplayString)(_ctx.$t('ToilLevel.template[9]')) + " " + (0,vue__WEBPACK_IMPORTED_MODULE_9__.toDisplayString)(index + 1), 1)];
                          }),
                          _: 2
                        }, 1032, ["modelValue", "onUpdate:modelValue"])];
                      }),
                      _: 2
                    }, 1024), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
                      modelValue: item.value1,
                      "onUpdate:modelValue": function onUpdateModelValue($event) {
                        return item.value1 = $event;
                      },
                      type: "number",
                      label: _ctx.$t('ToilLevel.template[10]'),
                      "label-width": "120",
                      placeholder: _ctx.$t('ToilLevel.templatePlaceholder[2]'),
                      "input-align": "right"
                    }, {
                      button: (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                        return [_hoisted_6];
                      }),
                      _: 2
                    }, 1032, ["modelValue", "onUpdate:modelValue", "label", "placeholder"]), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Field), {
                      modelValue: item.value2,
                      "onUpdate:modelValue": function onUpdateModelValue($event) {
                        return item.value2 = $event;
                      },
                      type: "number",
                      label: _ctx.$t('ToilLevel.template[11]'),
                      "label-width": "120",
                      placeholder: _ctx.$t('ToilLevel.templatePlaceholder[3]'),
                      "input-align": "right"
                    }, {
                      button: (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
                        return [_hoisted_7];
                      }),
                      _: 2
                    }, 1032, ["modelValue", "onUpdate:modelValue", "label", "placeholder"])];
                  }),
                  _: 2
                }, 1024);
              }), 128))];
            }),
            _: 1
          })];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(vant__WEBPACK_IMPORTED_MODULE_22__.Popup), {
        round: "",
        show: showPicker.value,
        "onUpdate:show": _cache[8] || (_cache[8] = function ($event) {
          return showPicker.value = $event;
        }),
        position: "bottom"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_9__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)(_components_Alarm_AlarmPicker_vue__WEBPACK_IMPORTED_MODULE_10__["default"], {
            columns: columns.value,
            showPicker: showPicker.value,
            defaultIndex: defaultIndex.value,
            onConfirm: onConfirm,
            onCancel: _cache[7] || (_cache[7] = function ($event) {
              return showPicker.value = false;
            })
          }, null, 8, ["columns", "showPicker", "defaultIndex"])];
        }),
        _: 1
      }, 8, ["show"]), _hoisted_8, (0,vue__WEBPACK_IMPORTED_MODULE_9__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_9__.unref)(StickyBottom), {
        onBottomSubmit: BottomSubmit,
        onBottomSearch: BottomSearch
      })], 64);
    };
  }
});

/***/ }),

/***/ "./src/views/phaseTwo/ToilLevel.vue":
/*!******************************************!*\
  !*** ./src/views/phaseTwo/ToilLevel.vue ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToilLevel_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToilLevel.vue?vue&type=script&setup=true&lang=js */ "./src/views/phaseTwo/ToilLevel.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _ToilLevel_vue_vue_type_style_index_0_id_39e3b458_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css */ "./src/views/phaseTwo/ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css");
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_vue_loader_17_0_0_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/_vue-loader@17.0.0@vue-loader/dist/exportHelper.js */ "./node_modules/_vue-loader@17.0.0@vue-loader/dist/exportHelper.js");



;


const __exports__ = /*#__PURE__*/(0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_vue_loader_17_0_0_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_ToilLevel_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"], [['__scopeId',"data-v-39e3b458"]])

/* harmony default export */ __webpack_exports__["default"] = (__exports__);

/***/ }),

/***/ "./src/views/phaseTwo/ToilLevel.vue?vue&type=script&setup=true&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/phaseTwo/ToilLevel.vue?vue&type=script&setup=true&lang=js ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* reexport safe */ _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_ToilLevel_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]; }
/* harmony export */ });
/* harmony import */ var _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_ToilLevel_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-41!../../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./ToilLevel.vue?vue&type=script&setup=true&lang=js */ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/ToilLevel.vue?vue&type=script&setup=true&lang=js");
 

/***/ }),

/***/ "./src/views/phaseTwo/ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css":
/*!**************************************************************************************************!*\
  !*** ./src/views/phaseTwo/ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_clonedRuleSet_12_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_use_1_node_modules_vue_loader_17_0_0_vue_loader_dist_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_use_2_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_ToilLevel_vue_vue_type_style_index_0_id_39e3b458_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!../../../node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!../../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css");


/***/ }),

/***/ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/ToilLevel.vue?vue&type=style&index=0&id=39e3b458&scoped=true&lang=css ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

}]);
//# sourceMappingURL=src_views_phaseTwo_ToilLevel_vue-src_components_Alarm_AlarmPicker_vue-src_components_ComConfi-c456f8.9486b560.js.map