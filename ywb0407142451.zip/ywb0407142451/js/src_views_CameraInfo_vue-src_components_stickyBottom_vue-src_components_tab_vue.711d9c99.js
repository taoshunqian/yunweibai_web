(self["webpackChunkyunweibao_ad"] = self["webpackChunkyunweibao_ad"] || []).push([["src_views_CameraInfo_vue-src_components_stickyBottom_vue-src_components_tab_vue"],{

/***/ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraInfo.vue?vue&type=script&setup=true&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraInfo.vue?vue&type=script&setup=true&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.index-of.js */ "./node_modules/core-js/modules/es.array.index-of.js");
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.timers.js */ "./node_modules/core-js/modules/web.timers.js");
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/toast/function-call.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/image/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/checkbox/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/popup/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/picker/index.mjs");
/* harmony import */ var _mixins_index_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../mixins/index.js */ "./src/mixins/index.js");














 // Checkbox



/* harmony default export */ __webpack_exports__["default"] = ({
  __name: 'CameraInfo',
  setup: function setup(__props) {
    var _mixins = (0,_mixins_index_js__WEBPACK_IMPORTED_MODULE_14__["default"])(),
        t = _mixins.t,
        postAN = _mixins.postAN,
        TabHeaders = _mixins.TabHeaders,
        StickyBottom = _mixins.StickyBottom,
        useRoute = _mixins.useRoute,
        callJSResult_Status = _mixins.callJSResult_Status;

    var route = useRoute();
    var query = route.query;
    var index = +query.index;
    var item = query.e;
    var allCmd = query.allCmd;
    var nowCmd = query.nowCmd; // console.log(allCmd.split(",")[0])
    // 标题

    var navTitle = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(t("cameraInfo.navTitle[0]") + (index + 1) + t("cameraInfo.navTitle[1]"));
    var defineColumns = ["960H", "720P", "1080P", "TVI 720P", "TVI 1080P", "CVI 720P", "CVI 1080P", "960P"]; // 2 4 6 1

    var testArr = [[1, 3], [2, 4]].join("!").replace(/,/g, "*");
    console.log(testArr.replace(/!/g, ","));
    var columns = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var checked = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(1); // 启用

    var checked2 = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(1); // 水平

    var checked3 = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(1); // 垂直

    var StateDisabled = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(true);
    var deviceColorIndex = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(1);
    var showPicker = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(false); // 弹出层是否显示

    var deviceCamera = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)("");
    var image = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)("");
    var mirrorCmd = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(""); // 镜像设置指令

    var cameraItems = []; // 设置选中的分辨率

    var onConfirm = function onConfirm(e) {
      deviceColorIndex.value = columns.value.indexOf(e);
      deviceCamera.value = e;
      showPicker.value = false;
    };

    var showPickerFn = function showPickerFn() {
      if (StateDisabled.value) {
        (0,vant__WEBPACK_IMPORTED_MODULE_15__.Toast)(t("toast[3]"));
        return false;
      }

      showPicker.value = true;
    }; // 是否启用


    var checkBoxChange = function checkBoxChange(e) {
      var bool = e;

      if (bool) {
        if (deviceCamera.value == "" || deviceCamera.value == undefined) {
          deviceCamera.value = cameraItems[0]; // 获取到当前选择的分辨率
        }
      }
    }; // 保存


    var BottomSubmit = function BottomSubmit() {
      var cmds = [];

      for (var i = 0; i < allCmd.length; i++) {
        if (i > 0) {
          var item = allCmd[i].split(":")[0];
          var cmd = item.split("#");
          cmds.push(cmd);
        }
      } // 获取到分辨率，在分辨率==0时为不启用


      if (deviceCamera.value != "") {
        var selectCamera = defineColumns.indexOf(deviceCamera.value); // console.warn(+checked.value)

        cmds[index][1] = +checked.value == 0 ? 0 : selectCamera + 1; // 不是是数组的索引，因此需要 +1，才是真正的值
      }

      var replaceCmd = cmds.join("!").replace(/,/g, "*").replace(/!/g, ",");
      var Cmd = replaceCmd.split(",");
      var powerCmd = [];

      for (var j = 0; j < Cmd.length; j++) {
        var powerItem = Cmd[j].split("*")[1];
        powerCmd.push(powerItem);
      }

      var resCmd = nowCmd + "," + allCmd[0] + "," + powerCmd.toString(); // 获取到摄像头设置的指令

      console.log(resCmd); // 镜像设置

      var mirror = mirrorCmd.value.split(",");
      var nowMirror = mirror[index + 1].split("*");
      nowMirror[1] = +checked2.value;
      nowMirror[2] = +checked3.value;
      nowMirror.join(",");
      mirror[index + 1] = nowMirror;
      var cmdsMirror = mirror.join("!").replace(/,/g, "*").replace(/!/g, ","); // console.log(cmdsMirror); // 获取到镜像设置

      postAN.ANsendSetting(cmdsMirror); // 镜像设置

      postAN.ANsendSetting(resCmd); // 摄像头设置

      return false;
    }; // 查询


    var BottomSearch = function BottomSearch() {
      (0,vant__WEBPACK_IMPORTED_MODULE_15__.Toast)(t("toast[0]"));
      androidStatus_fn();
    }; // 解析出支持设置的分辨率


    var splitStr = function splitStr() {
      var itemArr = item.split("#"); // 获取到是否启用

      console.warn(item);
      var cameraArr = itemArr[1].split(":"); // 分辨率

      console.warn("分辨率: " + cameraArr[0]);

      if (cameraArr[0] == 0) {
        checked.value = !!+cameraArr[0]; // 启用
      } else {
        checked.value = true;
      } // alert(cameraArr[0]);


      deviceCamera.value = defineColumns[cameraArr[0] - 1]; // 获取到当前选择的分辨率

      var cameraArr2 = cameraArr[1].split("*");

      for (var j = 0; j < cameraArr2.length; j++) {
        cameraItems.push(defineColumns[cameraArr2[j] - 1]);
      }

      columns.value = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(new Set(cameraItems)); // 显示 支持设置的分辨率

      deviceColorIndex.value = cameraItems.indexOf(deviceCamera.value); // 获取到分辨率的索引

      StateDisabled.value = false;
    }; // 命名空间


    (0,vue__WEBPACK_IMPORTED_MODULE_13__.defineComponent)({
      name: "yunweibao-CameraInfo"
    }); // -------------------------------------------------------------------
    // 安卓回调函数

    var callJSResult = function callJSResult(str) {
      var cmds = str.split(";")[0]; // 获取摄像头分辨率

      if (cmds.indexOf("CAMERAMODE") !== -1) {
        var cmdArr2 = cmds.split(",").splice(2); // console.log(cmds);

        var nowMirror2 = cmdArr2[index];
        item = nowMirror2;
        splitStr();
        postAN.ANSend("$MIRROR");
        return false;
      }

      mirrorCmd.value = cmds; // 获取到 镜像设置

      var cmdArr = cmds.split(",").splice(1); // alert(cmdArr[index]);

      vant__WEBPACK_IMPORTED_MODULE_15__.Toast.clear();
      console.warn(cmdArr);
      var nowMirror = cmdArr[index].split("*");
      checked2.value = +nowMirror[1];
      checked3.value = +nowMirror[2];
    }; // 安卓图片的回调函数


    var callJSResult_IMG = function callJSResult_IMG(state, data) {
      if (state == 0) {
        vant__WEBPACK_IMPORTED_MODULE_15__.Toast.success(state + index);
        return false;
      } else {
        image.value = data; // console.warn(data);
      }
    }; // 向安卓发送指令


    var androidStatus_fn = function androidStatus_fn() {
      vant__WEBPACK_IMPORTED_MODULE_15__.Toast.loading({
        forbidClick: true,
        loadingType: "spinner",
        duration: 0
      });
      setTimeout(function () {
        postAN.ANsendSelectPhoto(index);
      }, 800);
      postAN.ANSend("$CAMERAMODE");
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_13__.onMounted)(function () {
      window.callJSResult = callJSResult;
      window.callJSResult_Status = callJSResult_Status;
      window.callJSResult_IMG = callJSResult_IMG;
      androidStatus_fn();
      splitStr();
    });
    return function (_ctx, _cache) {
      return (0,vue__WEBPACK_IMPORTED_MODULE_13__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_13__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(TabHeaders), {
        navTitle: navTitle.value,
        leftArrow: false,
        lavelMuch: true
      }, null, 8, ["navTitle"]), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Image), {
            width: "100%",
            height: "40vh",
            src: image.value
          }, null, 8, ["src"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.Cell), {
            title: _ctx.$t('cameraInfo.title[0]')
          }, {
            "right-icon": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Checkbox), {
                modelValue: checked.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
                  return checked.value = $event;
                }),
                disabled: StateDisabled.value,
                shape: "square",
                "icon-size": "15px",
                onChange: checkBoxChange
              }, null, 8, ["modelValue", "disabled"])];
            }),
            _: 1
          }, 8, ["title"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.Cell), {
            title: _ctx.$t('cameraInfo.title[1]'),
            "is-link": "",
            value: deviceCamera.value,
            onClick: showPickerFn
          }, null, 8, ["title", "value"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.Cell), {
            title: _ctx.$t('cameraInfo.title[2]')
          }, {
            "right-icon": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Checkbox), {
                modelValue: checked2.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
                  return checked2.value = $event;
                }),
                shape: "square",
                "icon-size": "15px"
              }, null, 8, ["modelValue"])];
            }),
            _: 1
          }, 8, ["title"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.Cell), {
            title: _ctx.$t('cameraInfo.title[3]')
          }, {
            "right-icon": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Checkbox), {
                modelValue: checked3.value,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
                  return checked3.value = $event;
                }),
                shape: "square",
                "icon-size": "15px"
              }, null, 8, ["modelValue"])];
            }),
            _: 1
          }, 8, ["title"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_20__.Popup), {
        round: "",
        show: showPicker.value,
        "onUpdate:show": _cache[4] || (_cache[4] = function ($event) {
          return showPicker.value = $event;
        }),
        position: "bottom"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Picker), {
            title: _ctx.$t('cameraInfo.title[4]'),
            columns: columns.value,
            onCancel: _cache[3] || (_cache[3] = function ($event) {
              return showPicker.value = false;
            }),
            "default-index": deviceColorIndex.value,
            "confirm-button-text": _ctx.$t('picker[0]'),
            "cancel-button-text": _ctx.$t('picker[1]'),
            onConfirm: onConfirm
          }, null, 8, ["title", "columns", "default-index", "confirm-button-text", "cancel-button-text"])];
        }),
        _: 1
      }, 8, ["show"]), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(StickyBottom), {
        onBottomSubmit: BottomSubmit,
        onBottomSearch: BottomSearch
      })], 64);
    };
  }
});

/***/ }),

/***/ "./src/views/CameraInfo.vue":
/*!**********************************!*\
  !*** ./src/views/CameraInfo.vue ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CameraInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CameraInfo.vue?vue&type=script&setup=true&lang=js */ "./src/views/CameraInfo.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _CameraInfo_vue_vue_type_style_index_0_id_199af36a_lang_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css */ "./src/views/CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css");



;

const __exports__ = _CameraInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"];

/* harmony default export */ __webpack_exports__["default"] = (__exports__);

/***/ }),

/***/ "./src/views/CameraInfo.vue?vue&type=script&setup=true&lang=js":
/*!*********************************************************************!*\
  !*** ./src/views/CameraInfo.vue?vue&type=script&setup=true&lang=js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* reexport safe */ _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_CameraInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]; }
/* harmony export */ });
/* harmony import */ var _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_CameraInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-41!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./CameraInfo.vue?vue&type=script&setup=true&lang=js */ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraInfo.vue?vue&type=script&setup=true&lang=js");
 

/***/ }),

/***/ "./src/views/CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css":
/*!******************************************************************************!*\
  !*** ./src/views/CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_clonedRuleSet_12_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_use_1_node_modules_vue_loader_17_0_0_vue_loader_dist_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_use_2_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_CameraInfo_vue_vue_type_style_index_0_id_199af36a_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css");


/***/ }),

/***/ "./node_modules/core-js/internals/collection-strong.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/internals/collection-strong.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);
var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
var defineBuiltIns = __webpack_require__(/*! ../internals/define-built-ins */ "./node_modules/core-js/internals/define-built-ins.js");
var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
var anInstance = __webpack_require__(/*! ../internals/an-instance */ "./node_modules/core-js/internals/an-instance.js");
var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
var defineIterator = __webpack_require__(/*! ../internals/iterator-define */ "./node_modules/core-js/internals/iterator-define.js");
var createIterResultObject = __webpack_require__(/*! ../internals/create-iter-result-object */ "./node_modules/core-js/internals/create-iter-result-object.js");
var setSpecies = __webpack_require__(/*! ../internals/set-species */ "./node_modules/core-js/internals/set-species.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
var fastKey = (__webpack_require__(/*! ../internals/internal-metadata */ "./node_modules/core-js/internals/internal-metadata.js").fastKey);
var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");

var setInternalState = InternalStateModule.set;
var internalStateGetterFor = InternalStateModule.getterFor;

module.exports = {
  getConstructor: function (wrapper, CONSTRUCTOR_NAME, IS_MAP, ADDER) {
    var Constructor = wrapper(function (that, iterable) {
      anInstance(that, Prototype);
      setInternalState(that, {
        type: CONSTRUCTOR_NAME,
        index: create(null),
        first: undefined,
        last: undefined,
        size: 0
      });
      if (!DESCRIPTORS) that.size = 0;
      if (!isNullOrUndefined(iterable)) iterate(iterable, that[ADDER], { that: that, AS_ENTRIES: IS_MAP });
    });

    var Prototype = Constructor.prototype;

    var getInternalState = internalStateGetterFor(CONSTRUCTOR_NAME);

    var define = function (that, key, value) {
      var state = getInternalState(that);
      var entry = getEntry(that, key);
      var previous, index;
      // change existing entry
      if (entry) {
        entry.value = value;
      // create new entry
      } else {
        state.last = entry = {
          index: index = fastKey(key, true),
          key: key,
          value: value,
          previous: previous = state.last,
          next: undefined,
          removed: false
        };
        if (!state.first) state.first = entry;
        if (previous) previous.next = entry;
        if (DESCRIPTORS) state.size++;
        else that.size++;
        // add to index
        if (index !== 'F') state.index[index] = entry;
      } return that;
    };

    var getEntry = function (that, key) {
      var state = getInternalState(that);
      // fast case
      var index = fastKey(key);
      var entry;
      if (index !== 'F') return state.index[index];
      // frozen object case
      for (entry = state.first; entry; entry = entry.next) {
        if (entry.key == key) return entry;
      }
    };

    defineBuiltIns(Prototype, {
      // `{ Map, Set }.prototype.clear()` methods
      // https://tc39.es/ecma262/#sec-map.prototype.clear
      // https://tc39.es/ecma262/#sec-set.prototype.clear
      clear: function clear() {
        var that = this;
        var state = getInternalState(that);
        var data = state.index;
        var entry = state.first;
        while (entry) {
          entry.removed = true;
          if (entry.previous) entry.previous = entry.previous.next = undefined;
          delete data[entry.index];
          entry = entry.next;
        }
        state.first = state.last = undefined;
        if (DESCRIPTORS) state.size = 0;
        else that.size = 0;
      },
      // `{ Map, Set }.prototype.delete(key)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.delete
      // https://tc39.es/ecma262/#sec-set.prototype.delete
      'delete': function (key) {
        var that = this;
        var state = getInternalState(that);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.next;
          var prev = entry.previous;
          delete state.index[entry.index];
          entry.removed = true;
          if (prev) prev.next = next;
          if (next) next.previous = prev;
          if (state.first == entry) state.first = next;
          if (state.last == entry) state.last = prev;
          if (DESCRIPTORS) state.size--;
          else that.size--;
        } return !!entry;
      },
      // `{ Map, Set }.prototype.forEach(callbackfn, thisArg = undefined)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.foreach
      // https://tc39.es/ecma262/#sec-set.prototype.foreach
      forEach: function forEach(callbackfn /* , that = undefined */) {
        var state = getInternalState(this);
        var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
        var entry;
        while (entry = entry ? entry.next : state.first) {
          boundFunction(entry.value, entry.key, this);
          // revert to the last existing entry
          while (entry && entry.removed) entry = entry.previous;
        }
      },
      // `{ Map, Set}.prototype.has(key)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.has
      // https://tc39.es/ecma262/#sec-set.prototype.has
      has: function has(key) {
        return !!getEntry(this, key);
      }
    });

    defineBuiltIns(Prototype, IS_MAP ? {
      // `Map.prototype.get(key)` method
      // https://tc39.es/ecma262/#sec-map.prototype.get
      get: function get(key) {
        var entry = getEntry(this, key);
        return entry && entry.value;
      },
      // `Map.prototype.set(key, value)` method
      // https://tc39.es/ecma262/#sec-map.prototype.set
      set: function set(key, value) {
        return define(this, key === 0 ? 0 : key, value);
      }
    } : {
      // `Set.prototype.add(value)` method
      // https://tc39.es/ecma262/#sec-set.prototype.add
      add: function add(value) {
        return define(this, value = value === 0 ? 0 : value, value);
      }
    });
    if (DESCRIPTORS) defineProperty(Prototype, 'size', {
      get: function () {
        return getInternalState(this).size;
      }
    });
    return Constructor;
  },
  setStrong: function (Constructor, CONSTRUCTOR_NAME, IS_MAP) {
    var ITERATOR_NAME = CONSTRUCTOR_NAME + ' Iterator';
    var getInternalCollectionState = internalStateGetterFor(CONSTRUCTOR_NAME);
    var getInternalIteratorState = internalStateGetterFor(ITERATOR_NAME);
    // `{ Map, Set }.prototype.{ keys, values, entries, @@iterator }()` methods
    // https://tc39.es/ecma262/#sec-map.prototype.entries
    // https://tc39.es/ecma262/#sec-map.prototype.keys
    // https://tc39.es/ecma262/#sec-map.prototype.values
    // https://tc39.es/ecma262/#sec-map.prototype-@@iterator
    // https://tc39.es/ecma262/#sec-set.prototype.entries
    // https://tc39.es/ecma262/#sec-set.prototype.keys
    // https://tc39.es/ecma262/#sec-set.prototype.values
    // https://tc39.es/ecma262/#sec-set.prototype-@@iterator
    defineIterator(Constructor, CONSTRUCTOR_NAME, function (iterated, kind) {
      setInternalState(this, {
        type: ITERATOR_NAME,
        target: iterated,
        state: getInternalCollectionState(iterated),
        kind: kind,
        last: undefined
      });
    }, function () {
      var state = getInternalIteratorState(this);
      var kind = state.kind;
      var entry = state.last;
      // revert to the last existing entry
      while (entry && entry.removed) entry = entry.previous;
      // get next entry
      if (!state.target || !(state.last = entry = entry ? entry.next : state.state.first)) {
        // or finish the iteration
        state.target = undefined;
        return createIterResultObject(undefined, true);
      }
      // return step by kind
      if (kind == 'keys') return createIterResultObject(entry.key, false);
      if (kind == 'values') return createIterResultObject(entry.value, false);
      return createIterResultObject([entry.key, entry.value], false);
    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

    // `{ Map, Set }.prototype[@@species]` accessors
    // https://tc39.es/ecma262/#sec-get-map-@@species
    // https://tc39.es/ecma262/#sec-get-set-@@species
    setSpecies(CONSTRUCTOR_NAME);
  }
};


/***/ }),

/***/ "./node_modules/core-js/internals/collection.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/internals/collection.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var global = __webpack_require__(/*! ../internals/global */ "./node_modules/core-js/internals/global.js");
var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
var InternalMetadataModule = __webpack_require__(/*! ../internals/internal-metadata */ "./node_modules/core-js/internals/internal-metadata.js");
var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
var anInstance = __webpack_require__(/*! ../internals/an-instance */ "./node_modules/core-js/internals/an-instance.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var checkCorrectnessOfIteration = __webpack_require__(/*! ../internals/check-correctness-of-iteration */ "./node_modules/core-js/internals/check-correctness-of-iteration.js");
var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/core-js/internals/inherit-if-required.js");

module.exports = function (CONSTRUCTOR_NAME, wrapper, common) {
  var IS_MAP = CONSTRUCTOR_NAME.indexOf('Map') !== -1;
  var IS_WEAK = CONSTRUCTOR_NAME.indexOf('Weak') !== -1;
  var ADDER = IS_MAP ? 'set' : 'add';
  var NativeConstructor = global[CONSTRUCTOR_NAME];
  var NativePrototype = NativeConstructor && NativeConstructor.prototype;
  var Constructor = NativeConstructor;
  var exported = {};

  var fixMethod = function (KEY) {
    var uncurriedNativeMethod = uncurryThis(NativePrototype[KEY]);
    defineBuiltIn(NativePrototype, KEY,
      KEY == 'add' ? function add(value) {
        uncurriedNativeMethod(this, value === 0 ? 0 : value);
        return this;
      } : KEY == 'delete' ? function (key) {
        return IS_WEAK && !isObject(key) ? false : uncurriedNativeMethod(this, key === 0 ? 0 : key);
      } : KEY == 'get' ? function get(key) {
        return IS_WEAK && !isObject(key) ? undefined : uncurriedNativeMethod(this, key === 0 ? 0 : key);
      } : KEY == 'has' ? function has(key) {
        return IS_WEAK && !isObject(key) ? false : uncurriedNativeMethod(this, key === 0 ? 0 : key);
      } : function set(key, value) {
        uncurriedNativeMethod(this, key === 0 ? 0 : key, value);
        return this;
      }
    );
  };

  var REPLACE = isForced(
    CONSTRUCTOR_NAME,
    !isCallable(NativeConstructor) || !(IS_WEAK || NativePrototype.forEach && !fails(function () {
      new NativeConstructor().entries().next();
    }))
  );

  if (REPLACE) {
    // create collection constructor
    Constructor = common.getConstructor(wrapper, CONSTRUCTOR_NAME, IS_MAP, ADDER);
    InternalMetadataModule.enable();
  } else if (isForced(CONSTRUCTOR_NAME, true)) {
    var instance = new Constructor();
    // early implementations not supports chaining
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    // V8 ~ Chromium 40- weak-collections throws on primitives, but should return false
    var THROWS_ON_PRIMITIVES = fails(function () { instance.has(1); });
    // most early implementations doesn't supports iterables, most modern - not close it correctly
    // eslint-disable-next-line no-new -- required for testing
    var ACCEPT_ITERABLES = checkCorrectnessOfIteration(function (iterable) { new NativeConstructor(iterable); });
    // for early implementations -0 and +0 not the same
    var BUGGY_ZERO = !IS_WEAK && fails(function () {
      // V8 ~ Chromium 42- fails only with 5+ elements
      var $instance = new NativeConstructor();
      var index = 5;
      while (index--) $instance[ADDER](index, index);
      return !$instance.has(-0);
    });

    if (!ACCEPT_ITERABLES) {
      Constructor = wrapper(function (dummy, iterable) {
        anInstance(dummy, NativePrototype);
        var that = inheritIfRequired(new NativeConstructor(), dummy, Constructor);
        if (!isNullOrUndefined(iterable)) iterate(iterable, that[ADDER], { that: that, AS_ENTRIES: IS_MAP });
        return that;
      });
      Constructor.prototype = NativePrototype;
      NativePrototype.constructor = Constructor;
    }

    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }

    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);

    // weak collections should not contains .clear method
    if (IS_WEAK && NativePrototype.clear) delete NativePrototype.clear;
  }

  exported[CONSTRUCTOR_NAME] = Constructor;
  $({ global: true, constructor: true, forced: Constructor != NativeConstructor }, exported);

  setToStringTag(Constructor, CONSTRUCTOR_NAME);

  if (!IS_WEAK) common.setStrong(Constructor, CONSTRUCTOR_NAME, IS_MAP);

  return Constructor;
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.set.constructor.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es.set.constructor.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var collection = __webpack_require__(/*! ../internals/collection */ "./node_modules/core-js/internals/collection.js");
var collectionStrong = __webpack_require__(/*! ../internals/collection-strong */ "./node_modules/core-js/internals/collection-strong.js");

// `Set` constructor
// https://tc39.es/ecma262/#sec-set-objects
collection('Set', function (init) {
  return function Set() { return init(this, arguments.length ? arguments[0] : undefined); };
}, collectionStrong);


/***/ }),

/***/ "./node_modules/core-js/modules/es.set.js":
/*!************************************************!*\
  !*** ./node_modules/core-js/modules/es.set.js ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// TODO: Remove this module from `core-js@4` since it's replaced to module below
__webpack_require__(/*! ../modules/es.set.constructor */ "./node_modules/core-js/modules/es.set.constructor.js");


/***/ }),

/***/ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraInfo.vue?vue&type=style&index=0&id=199af36a&lang=css ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/cell-group/CellGroup.mjs":
/*!*******************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/cell-group/CellGroup.mjs ***!
  \*******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/constant.mjs");



const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("cell-group");
const cellGroupProps = {
  title: String,
  inset: Boolean,
  border: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.truthProp
};
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  inheritAttrs: false,
  props: cellGroupProps,

  setup(props, {
    slots,
    attrs
  }) {
    const renderGroup = () => {
      var _a;

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", (0,vue__WEBPACK_IMPORTED_MODULE_0__.mergeProps)({
        "class": [bem({
          inset: props.inset
        }), {
          [_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.BORDER_TOP_BOTTOM]: props.border && !props.inset
        }]
      }, attrs), [(_a = slots.default) == null ? void 0 : _a.call(slots)]);
    };

    const renderTitle = () => (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
      "class": bem("title", {
        inset: props.inset
      })
    }, [slots.title ? slots.title() : props.title]);

    return () => {
      if (props.title || slots.title) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [renderTitle(), renderGroup()]);
      }

      return renderGroup();
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs":
/*!***************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs ***!
  \***************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CellGroup": function() { return /* binding */ CellGroup; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/with-install.mjs");
/* harmony import */ var _CellGroup_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CellGroup.mjs */ "./node_modules/_vant@3.6.2@vant/es/cell-group/CellGroup.mjs");


const CellGroup = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__.withInstall)(_CellGroup_mjs__WEBPACK_IMPORTED_MODULE_1__["default"]);
var stdin_default = CellGroup;


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/cell/Cell.mjs":
/*!********************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/cell/Cell.mjs ***!
  \********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cellSharedProps": function() { return /* binding */ cellSharedProps; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/basic.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/validate.mjs");
/* harmony import */ var _composables_use_route_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../composables/use-route.mjs */ "./node_modules/_vant@3.6.2@vant/es/composables/use-route.mjs");
/* harmony import */ var _icon_index_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/icon/index.mjs");





const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("cell");
const cellSharedProps = {
  icon: String,
  size: String,
  title: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  value: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  label: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  center: Boolean,
  isLink: Boolean,
  border: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.truthProp,
  required: Boolean,
  iconPrefix: String,
  valueClass: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.unknownProp,
  labelClass: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.unknownProp,
  titleClass: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.unknownProp,
  titleStyle: null,
  arrowDirection: String,
  clickable: {
    type: Boolean,
    default: null
  }
};
const cellProps = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.extend)({}, cellSharedProps, _composables_use_route_mjs__WEBPACK_IMPORTED_MODULE_4__.routeProps);
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  props: cellProps,

  setup(props, {
    slots
  }) {
    const route = (0,_composables_use_route_mjs__WEBPACK_IMPORTED_MODULE_4__.useRoute)();

    const renderLabel = () => {
      const showLabel = slots.label || (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__.isDef)(props.label);

      if (showLabel) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
          "class": [bem("label"), props.labelClass]
        }, [slots.label ? slots.label() : props.label]);
      }
    };

    const renderTitle = () => {
      if (slots.title || (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__.isDef)(props.title)) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
          "class": [bem("title"), props.titleClass],
          "style": props.titleStyle
        }, [slots.title ? slots.title() : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("span", null, [props.title]), renderLabel()]);
      }
    };

    const renderValue = () => {
      const slot = slots.value || slots.default;
      const hasValue = slot || (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__.isDef)(props.value);

      if (hasValue) {
        const hasTitle = slots.title || (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__.isDef)(props.title);
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
          "class": [bem("value", {
            alone: !hasTitle
          }), props.valueClass]
        }, [slot ? slot() : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("span", null, [props.value])]);
      }
    };

    const renderLeftIcon = () => {
      if (slots.icon) {
        return slots.icon();
      }

      if (props.icon) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_icon_index_mjs__WEBPACK_IMPORTED_MODULE_6__.Icon, {
          "name": props.icon,
          "class": bem("left-icon"),
          "classPrefix": props.iconPrefix
        }, null);
      }
    };

    const renderRightIcon = () => {
      if (slots["right-icon"]) {
        return slots["right-icon"]();
      }

      if (props.isLink) {
        const name2 = props.arrowDirection ? `arrow-${props.arrowDirection}` : "arrow";
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_icon_index_mjs__WEBPACK_IMPORTED_MODULE_6__.Icon, {
          "name": name2,
          "class": bem("right-icon")
        }, null);
      }
    };

    return () => {
      var _a, _b;

      const {
        size,
        center,
        border,
        isLink,
        required
      } = props;
      const clickable = (_a = props.clickable) != null ? _a : isLink;
      const classes = {
        center,
        required,
        clickable,
        borderless: !border
      };

      if (size) {
        classes[size] = !!size;
      }

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "class": bem(classes),
        "role": clickable ? "button" : void 0,
        "tabindex": clickable ? 0 : void 0,
        "onClick": route
      }, [renderLeftIcon(), renderTitle(), renderValue(), renderRightIcon(), (_b = slots.extra) == null ? void 0 : _b.call(slots)]);
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/cell/index.mjs":
/*!*********************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/cell/index.mjs ***!
  \*********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Cell": function() { return /* binding */ Cell; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/with-install.mjs");
/* harmony import */ var _Cell_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Cell.mjs */ "./node_modules/_vant@3.6.2@vant/es/cell/Cell.mjs");


const Cell = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__.withInstall)(_Cell_mjs__WEBPACK_IMPORTED_MODULE_1__["default"]);
var stdin_default = Cell;


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/checkbox-group/CheckboxGroup.mjs":
/*!***************************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/checkbox-group/CheckboxGroup.mjs ***!
  \***************************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CHECKBOX_GROUP_KEY": function() { return /* binding */ CHECKBOX_GROUP_KEY; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _vant_use__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @vant/use */ "./node_modules/_@vant_use@1.4.2@@vant/use/dist/index.esm.mjs");
/* harmony import */ var _composables_use_expose_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../composables/use-expose.mjs */ "./node_modules/_vant@3.6.2@vant/es/composables/use-expose.mjs");





const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("checkbox-group");
const checkboxGroupProps = {
  max: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  disabled: Boolean,
  iconSize: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  direction: String,
  modelValue: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.makeArrayProp)(),
  checkedColor: String
};
const CHECKBOX_GROUP_KEY = Symbol(name);
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  props: checkboxGroupProps,
  emits: ["change", "update:modelValue"],

  setup(props, {
    emit,
    slots
  }) {
    const {
      children,
      linkChildren
    } = (0,_vant_use__WEBPACK_IMPORTED_MODULE_3__.useChildren)(CHECKBOX_GROUP_KEY);

    const updateValue = value => emit("update:modelValue", value);

    const toggleAll = (options = {}) => {
      if (typeof options === "boolean") {
        options = {
          checked: options
        };
      }

      const {
        checked,
        skipDisabled
      } = options;
      const checkedChildren = children.filter(item => {
        if (!item.props.bindGroup) {
          return false;
        }

        if (item.props.disabled && skipDisabled) {
          return item.checked.value;
        }

        return checked != null ? checked : !item.checked.value;
      });
      const names = checkedChildren.map(item => item.name);
      updateValue(names);
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_0__.watch)(() => props.modelValue, value => emit("change", value));
    (0,_composables_use_expose_mjs__WEBPACK_IMPORTED_MODULE_4__.useExpose)({
      toggleAll
    });
    (0,_vant_use__WEBPACK_IMPORTED_MODULE_3__.useCustomFieldValue)(() => props.modelValue);
    linkChildren({
      props,
      updateValue
    });
    return () => {
      var _a;

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "class": bem([props.direction])
      }, [(_a = slots.default) == null ? void 0 : _a.call(slots)]);
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/checkbox/Checkbox.mjs":
/*!****************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/checkbox/Checkbox.mjs ***!
  \****************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/basic.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _checkbox_group_CheckboxGroup_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../checkbox-group/CheckboxGroup.mjs */ "./node_modules/_vant@3.6.2@vant/es/checkbox-group/CheckboxGroup.mjs");
/* harmony import */ var _vant_use__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @vant/use */ "./node_modules/_@vant_use@1.4.2@@vant/use/dist/index.esm.mjs");
/* harmony import */ var _composables_use_expose_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../composables/use-expose.mjs */ "./node_modules/_vant@3.6.2@vant/es/composables/use-expose.mjs");
/* harmony import */ var _Checker_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Checker.mjs */ "./node_modules/_vant@3.6.2@vant/es/checkbox/Checker.mjs");







const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("checkbox");
const checkboxProps = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.extend)({}, _Checker_mjs__WEBPACK_IMPORTED_MODULE_3__.checkerProps, {
  bindGroup: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_4__.truthProp
});
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  props: checkboxProps,
  emits: ["change", "update:modelValue"],

  setup(props, {
    emit,
    slots
  }) {
    const {
      parent
    } = (0,_vant_use__WEBPACK_IMPORTED_MODULE_5__.useParent)(_checkbox_group_CheckboxGroup_mjs__WEBPACK_IMPORTED_MODULE_6__.CHECKBOX_GROUP_KEY);

    const setParentValue = checked2 => {
      const {
        name: name2
      } = props;
      const {
        max,
        modelValue
      } = parent.props;
      const value = modelValue.slice();

      if (checked2) {
        const overlimit = max && value.length >= max;

        if (!overlimit && !value.includes(name2)) {
          value.push(name2);

          if (props.bindGroup) {
            parent.updateValue(value);
          }
        }
      } else {
        const index = value.indexOf(name2);

        if (index !== -1) {
          value.splice(index, 1);

          if (props.bindGroup) {
            parent.updateValue(value);
          }
        }
      }
    };

    const checked = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      if (parent && props.bindGroup) {
        return parent.props.modelValue.indexOf(props.name) !== -1;
      }

      return !!props.modelValue;
    });

    const toggle = (newValue = !checked.value) => {
      if (parent && props.bindGroup) {
        setParentValue(newValue);
      } else {
        emit("update:modelValue", newValue);
      }
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_0__.watch)(() => props.modelValue, value => emit("change", value));
    (0,_composables_use_expose_mjs__WEBPACK_IMPORTED_MODULE_7__.useExpose)({
      toggle,
      props,
      checked
    });
    (0,_vant_use__WEBPACK_IMPORTED_MODULE_5__.useCustomFieldValue)(() => props.modelValue);
    return () => (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_Checker_mjs__WEBPACK_IMPORTED_MODULE_3__["default"], (0,vue__WEBPACK_IMPORTED_MODULE_0__.mergeProps)({
      "bem": bem,
      "role": "checkbox",
      "parent": parent,
      "checked": checked.value,
      "onToggle": toggle
    }, props), (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.pick)(slots, ["default", "icon"]));
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/checkbox/Checker.mjs":
/*!***************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/checkbox/Checker.mjs ***!
  \***************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "checkerProps": function() { return /* binding */ checkerProps; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/basic.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/format.mjs");
/* harmony import */ var _icon_index_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/icon/index.mjs");




const checkerProps = {
  name: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.unknownProp,
  shape: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.makeStringProp)("round"),
  disabled: Boolean,
  iconSize: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.numericProp,
  modelValue: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.unknownProp,
  checkedColor: String,
  labelPosition: String,
  labelDisabled: Boolean
};
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  props: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.extend)({}, checkerProps, {
    bem: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.makeRequiredProp)(Function),
    role: String,
    parent: Object,
    checked: Boolean,
    bindGroup: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.truthProp
  }),
  emits: ["click", "toggle"],

  setup(props, {
    emit,
    slots
  }) {
    const iconRef = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)();

    const getParentProp = name => {
      if (props.parent && props.bindGroup) {
        return props.parent.props[name];
      }
    };

    const disabled = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => getParentProp("disabled") || props.disabled);
    const direction = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => getParentProp("direction"));
    const iconStyle = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const checkedColor = props.checkedColor || getParentProp("checkedColor");

      if (checkedColor && props.checked && !disabled.value) {
        return {
          borderColor: checkedColor,
          backgroundColor: checkedColor
        };
      }
    });

    const onClick = event => {
      const {
        target
      } = event;
      const icon = iconRef.value;
      const iconClicked = icon === target || (icon == null ? void 0 : icon.contains(target));

      if (!disabled.value && (iconClicked || !props.labelDisabled)) {
        emit("toggle");
      }

      emit("click", event);
    };

    const renderIcon = () => {
      const {
        bem,
        shape,
        checked
      } = props;
      const iconSize = props.iconSize || getParentProp("iconSize");
      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "ref": iconRef,
        "class": bem("icon", [shape, {
          disabled: disabled.value,
          checked
        }]),
        "style": {
          fontSize: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.addUnit)(iconSize)
        }
      }, [slots.icon ? slots.icon({
        checked,
        disabled: disabled.value
      }) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_icon_index_mjs__WEBPACK_IMPORTED_MODULE_4__.Icon, {
        "name": "success",
        "style": iconStyle.value
      }, null)]);
    };

    const renderLabel = () => {
      if (slots.default) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("span", {
          "class": props.bem("label", [props.labelPosition, {
            disabled: disabled.value
          }])
        }, [slots.default()]);
      }
    };

    return () => {
      const nodes = props.labelPosition === "left" ? [renderLabel(), renderIcon()] : [renderIcon(), renderLabel()];
      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "role": props.role,
        "class": props.bem([{
          disabled: disabled.value,
          "label-disabled": props.labelDisabled
        }, direction.value]),
        "tabindex": disabled.value ? void 0 : 0,
        "aria-checked": props.checked,
        "onClick": onClick
      }, [nodes]);
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/checkbox/index.mjs":
/*!*************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/checkbox/index.mjs ***!
  \*************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Checkbox": function() { return /* binding */ Checkbox; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/with-install.mjs");
/* harmony import */ var _Checkbox_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Checkbox.mjs */ "./node_modules/_vant@3.6.2@vant/es/checkbox/Checkbox.mjs");


const Checkbox = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__.withInstall)(_Checkbox_mjs__WEBPACK_IMPORTED_MODULE_1__["default"]);
var stdin_default = Checkbox;


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/image/Image.mjs":
/*!**********************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/image/Image.mjs ***!
  \**********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/format.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/validate.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/basic.mjs");
/* harmony import */ var _icon_index_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../icon/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/icon/index.mjs");




const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("image");
const imageProps = {
  src: String,
  alt: String,
  fit: String,
  position: String,
  round: Boolean,
  width: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  height: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  radius: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  lazyLoad: Boolean,
  iconSize: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  showError: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.truthProp,
  errorIcon: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.makeStringProp)("photo-fail"),
  iconPrefix: String,
  showLoading: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.truthProp,
  loadingIcon: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.makeStringProp)("photo")
};
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  props: imageProps,
  emits: ["load", "error"],

  setup(props, {
    emit,
    slots
  }) {
    const error = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const loading = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(true);
    const imageRef = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)();
    const {
      $Lazyload
    } = (0,vue__WEBPACK_IMPORTED_MODULE_0__.getCurrentInstance)().proxy;
    const style = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const style2 = {
        width: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.addUnit)(props.width),
        height: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.addUnit)(props.height)
      };

      if ((0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_4__.isDef)(props.radius)) {
        style2.overflow = "hidden";
        style2.borderRadius = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.addUnit)(props.radius);
      }

      return style2;
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.watch)(() => props.src, () => {
      error.value = false;
      loading.value = true;
    });

    const onLoad = event => {
      loading.value = false;
      emit("load", event);
    };

    const onError = event => {
      error.value = true;
      loading.value = false;
      emit("error", event);
    };

    const renderIcon = (name2, className, slot) => {
      if (slot) {
        return slot();
      }

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_icon_index_mjs__WEBPACK_IMPORTED_MODULE_5__.Icon, {
        "name": name2,
        "size": props.iconSize,
        "class": className,
        "classPrefix": props.iconPrefix
      }, null);
    };

    const renderPlaceholder = () => {
      if (loading.value && props.showLoading) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
          "class": bem("loading")
        }, [renderIcon(props.loadingIcon, bem("loading-icon"), slots.loading)]);
      }

      if (error.value && props.showError) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
          "class": bem("error")
        }, [renderIcon(props.errorIcon, bem("error-icon"), slots.error)]);
      }
    };

    const renderImage = () => {
      if (error.value || !props.src) {
        return;
      }

      const attrs = {
        alt: props.alt,
        class: bem("img"),
        style: {
          objectFit: props.fit,
          objectPosition: props.position
        }
      };

      if (props.lazyLoad) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("img", (0,vue__WEBPACK_IMPORTED_MODULE_0__.mergeProps)({
          "ref": imageRef
        }, attrs), null), [[(0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveDirective)("lazy"), props.src]]);
      }

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("img", (0,vue__WEBPACK_IMPORTED_MODULE_0__.mergeProps)({
        "src": props.src,
        "onLoad": onLoad,
        "onError": onError
      }, attrs), null);
    };

    const onLazyLoaded = ({
      el
    }) => {
      const check = () => {
        if (el === imageRef.value && loading.value) {
          onLoad();
        }
      };

      if (imageRef.value) {
        check();
      } else {
        (0,vue__WEBPACK_IMPORTED_MODULE_0__.nextTick)(check);
      }
    };

    const onLazyLoadError = ({
      el
    }) => {
      if (el === imageRef.value && !error.value) {
        onError();
      }
    };

    if ($Lazyload && _utils_index_mjs__WEBPACK_IMPORTED_MODULE_6__.inBrowser) {
      $Lazyload.$on("loaded", onLazyLoaded);
      $Lazyload.$on("error", onLazyLoadError);
      (0,vue__WEBPACK_IMPORTED_MODULE_0__.onBeforeUnmount)(() => {
        $Lazyload.$off("loaded", onLazyLoaded);
        $Lazyload.$off("error", onLazyLoadError);
      });
    }

    return () => {
      var _a;

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "class": bem({
          round: props.round
        }),
        "style": style.value
      }, [renderImage(), renderPlaceholder(), (_a = slots.default) == null ? void 0 : _a.call(slots)]);
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/image/index.mjs":
/*!**********************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/image/index.mjs ***!
  \**********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Image": function() { return /* binding */ Image; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/with-install.mjs");
/* harmony import */ var _Image_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Image.mjs */ "./node_modules/_vant@3.6.2@vant/es/image/Image.mjs");


const Image = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__.withInstall)(_Image_mjs__WEBPACK_IMPORTED_MODULE_1__["default"]);
var stdin_default = Image;


/***/ })

}]);
//# sourceMappingURL=src_views_CameraInfo_vue-src_components_stickyBottom_vue-src_components_tab_vue.711d9c99.js.map