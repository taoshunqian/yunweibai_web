"use strict";
(self["webpackChunkyunweibao_ad"] = self["webpackChunkyunweibao_ad"] || []).push([["src_views_phaseTwo_LoadSettings_vue-src_components_Alarm_AlarmPicker_vue-src_components_ComCo-4f92f9"],{

/***/ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/LoadSettings.vue?vue&type=script&setup=true&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/LoadSettings.vue?vue&type=script&setup=true&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.for-each.js */ "./node_modules/core-js/modules/es.array.for-each.js");
/* harmony import */ var core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.date.to-string.js */ "./node_modules/core-js/modules/es.date.to-string.js");
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.index-of.js */ "./node_modules/core-js/modules/es.array.index-of.js");
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.timers.js */ "./node_modules/core-js/modules/web.timers.js");
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_ComConfig_vue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/ComConfig.vue */ "./src/components/ComConfig.vue");
/* harmony import */ var _components_Alarm_AlarmPicker_vue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/Alarm//AlarmPicker.vue */ "./src/components/Alarm/AlarmPicker.vue");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/toast/function-call.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/field/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/row/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/col/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/button/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/checkbox/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/popup/index.mjs");
/* harmony import */ var _utlis_QueryStr__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/utlis/QueryStr */ "./src/utlis/QueryStr.js");
/* harmony import */ var _mixins_index_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/mixins/index.js */ "./src/mixins/index.js");















var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_13__.pushScopeId)("data-v-58cf7cea"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_13__.popScopeId)(), n;
};

var _hoisted_1 = {
  style: {
    "display": "none"
  }
};

var _hoisted_2 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("span", null, "MV", -1);
});

var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("span", null, "KG", -1);
});

var _hoisted_4 = {
  style: {
    "margin-top": "20px",
    "background": "#ffffff"
  }
};

var _hoisted_5 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("span", null, "MV", -1);
});

var _hoisted_6 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("span", null, "KG", -1);
});

var _hoisted_7 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("footer", {
    style: {
      "padding-bottom": "50px"
    }
  }, null, -1);
});



 // Checkbox




/* harmony default export */ __webpack_exports__["default"] = ({
  __name: 'LoadSettings',
  setup: function setup(__props) {
    /*
    报警器 和 刷卡器 共用
    */
    var _mixins = (0,_mixins_index_js__WEBPACK_IMPORTED_MODULE_17__["default"])(),
        t = _mixins.t,
        postAN = _mixins.postAN,
        TabHeaders = _mixins.TabHeaders,
        StickyBottom = _mixins.StickyBottom,
        callJSResult_Status = _mixins.callJSResult_Status;

    var showPicker = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(false);
    var columns = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var defaultIndex = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(0);
    var navTitle = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(t('LoadSettings.navTitle'));
    var resultAll = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)("");
    var maxNum = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(0);
    var comAllCmdInfo = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var cmdCmdInfo = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var loadCmdInfo = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var coloumsMode = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var addCalibrationInfo = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)([]);
    var status = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(true); // 状态更新

    var isSend = (0,vue__WEBPACK_IMPORTED_MODULE_13__.ref)(false); // 是否允许设置参数
    // 命名空间

    (0,vue__WEBPACK_IMPORTED_MODULE_13__.defineComponent)({
      name: "yunweibao-LoadSettings"
    }); // 弹出 picker 选择器

    var showPickerFn = function showPickerFn(num) {
      showPicker.value = true;

      switch (num) {
        case 1:
          // 协议类型
          columns.value = coloumsMode.value;
          defaultIndex.value = loadCmdInfo.value[1];
          break;
      }
    }; // picker 弹出层确认


    var onConfirm = function onConfirm(items) {
      loadCmdInfo.value[1] = items[1];
      showPicker.value = false;
    };

    var BottomSubmit = function BottomSubmit() {
      var arr = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(addCalibrationInfo.value);

      var str = "";
      arr.forEach(function (item) {
        str += "," + item.value1 + "," + item.value2;
      });
      str = "$WEGIHTCAL" + str;
      postAN.ANsendSetting(str); // 载重列表

      status.value = !status.value;
      isSend.value = true;
    };

    var comConfirm = function comConfirm(items) {
      if (isSend.value) {
        var comInfo = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(comAllCmdInfo.value);

        var index = items.item[0];
        comInfo[index - 1] = items.item;
        comInfo.forEach(function (item) {
          var send = "$UARTSET," + item.toString();
          console.log(send);
          postAN.ANsendSetting(send); // 串口信息设置
        });
        var send2 = "$PREWEIGHT," + loadCmdInfo.value[1];
        postAN.ANsendSetting(send2); // 设置传感器
      }
    };

    var deleteCalibrationInfoFn = function deleteCalibrationInfoFn() {
      var arr = addCalibrationInfo.value;
      arr.filter(function (value, index, arr) {
        if (value.check) {
          arr.splice(index, 1);
        }
      });
      loadCmdInfo.value[4] = arr.length;
    };

    var addCalibrationInfoFn = function addCalibrationInfoFn() {
      var arr = addCalibrationInfo.value;
      loadCmdInfo.value[4] = +loadCmdInfo.value[4] + 1; // 标定数目

      if (arr.length == 15) {
        vant__WEBPACK_IMPORTED_MODULE_18__.Toast.fail(t('LoadSettings.fail[0]'));
        return false;
      }

      arr.push({
        check: false,
        value1: "1",
        value2: "1"
      });
    }; // 解析串口数据


    var getComInfo = function getComInfo(comCmd) {
      var comArr = [];
      comCmd.forEach(function (item) {
        if (item.indexOf("52") !== -1) {
          var its = item.split("~");
          its[1] = its[0];
          its[0] = "52";
          cmdCmdInfo.value = its;
        }

        var it = item.split("~");
        it[1] = it[1].split("*")[0];
        comArr.push(it);
      });
      return comArr;
    };

    function getNewArray(array, subGroupLength) {
      var index = 0;
      var newArray = [];

      while (index < array.length) {
        newArray.push(array.slice(index, index += subGroupLength));
      }

      return newArray;
    } // 标定数目 解析数据


    var encodeCalibrationInfo = function encodeCalibrationInfo(calibrationCmd) {
      var arr = addCalibrationInfo.value;

      if (calibrationCmd.length > 0) {
        var res = getNewArray(calibrationCmd, 2);
        res.forEach(function (item) {
          arr.push({
            check: false,
            value1: (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_16__.keepDecimal)(item[0], 2),
            value2: (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_16__.keepDecimal)(item[1], 2)
          });
        });
      }
    };

    var filterModel = function filterModel(data) {
      var arr = [];

      for (var i = 0; i < data.length; i++) {
        if (data[i] == "wegihtWithUart") {
          arr.push(t('LoadSettings.model'));
        } else {
          arr.push(data[i]);
        }
      }

      return arr;
    }; // -------------------------------------------------------------------
    // 安卓回调函数r


    var callJSResult = function callJSResult(str) {
      var cmds = str.split(";")[0];
      maxNum.value++;
      resultAll.value += cmds + "!";

      if (maxNum.value == 3) {
        var allcmd = resultAll.value.split("!");
        var comCmd = allcmd[0].split(",").splice(1); // 串口指令

        var loadCmd = allcmd[1].split(",").splice(1);
        var calibrationCmd = allcmd[2].split(",").splice(1);
        encodeCalibrationInfo(calibrationCmd);
        coloumsMode.value = filterModel(loadCmd[0].split("*"));
        loadCmd[2] = Math.floor(loadCmd[2] * 10) / 10;
        loadCmd[3] = Math.floor(loadCmd[3] * 10) / 10;
        loadCmdInfo.value = loadCmd;
        allcmd.pop(); // 去除最后一位的空值

        comAllCmdInfo.value = getComInfo(comCmd);
        return;
      }
    }; // 向安卓发送指令


    var androidStatus_fn = function androidStatus_fn() {
      postAN.ANSend("$UARTSET");
      setTimeout(function () {
        postAN.ANSend("$PREWEIGHT");
      }, 500);
      setTimeout(function () {
        postAN.ANSend("$WEGIHTCAL");
      }, 1000);
    };

    androidStatus_fn();
    (0,vue__WEBPACK_IMPORTED_MODULE_13__.onMounted)(function () {
      window.callJSResult = callJSResult;
      window.callJSResult_Status = callJSResult_Status;
    });
    return function (_ctx, _cache) {
      return (0,vue__WEBPACK_IMPORTED_MODULE_13__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_13__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(TabHeaders), {
        navTitle: navTitle.value,
        leftArrow: false
      }, null, 8, ["navTitle"]), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)(_components_ComConfig_vue__WEBPACK_IMPORTED_MODULE_14__["default"], {
        loadCmdInfo: loadCmdInfo.value,
        status: status.value,
        cmdCmdInfo: cmdCmdInfo.value,
        onComConfirm: comConfirm
      }, null, 8, ["loadCmdInfo", "status", "cmdCmdInfo"])]), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_20__.Cell), {
            title: _ctx.$t('LoadSettings.template[0]'),
            "is-link": "",
            value: coloumsMode.value[loadCmdInfo.value[1]],
            onClick: _cache[0] || (_cache[0] = function ($event) {
              return showPickerFn(1);
            })
          }, null, 8, ["title", "value"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Field), {
            type: "tel",
            label: _ctx.$t('LoadSettings.template[1]'),
            "label-width": "120",
            placeholder: _ctx.$t('LoadSettings.templatePlaceholder[0]'),
            "input-align": "right",
            readonly: "",
            modelValue: loadCmdInfo.value[2],
            "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
              return loadCmdInfo.value[2] = $event;
            })
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [_hoisted_2];
            }),
            _: 1
          }, 8, ["label", "placeholder", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.CellGroup), {
        inset: "",
        "class": "cell-group"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Field), {
            type: "tel",
            label: _ctx.$t('LoadSettings.template[2]'),
            "label-width": "120",
            placeholder: _ctx.$t('LoadSettings.templatePlaceholder[1]'),
            "input-align": "right",
            readonly: "",
            modelValue: loadCmdInfo.value[3],
            "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
              return loadCmdInfo.value[3] = $event;
            })
          }, {
            button: (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [_hoisted_3];
            }),
            _: 1
          }, 8, ["label", "placeholder", "modelValue"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_22__.Row), null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_23__.Col), {
            span: "16"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.CellGroup), null, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Field), {
                    type: "tel",
                    label: _ctx.$t('LoadSettings.template[3]'),
                    "label-width": "120",
                    placeholder: _ctx.$t('LoadSettings.templatePlaceholder[2]'),
                    "input-align": "right",
                    modelValue: loadCmdInfo.value[4],
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
                      return loadCmdInfo.value[4] = $event;
                    }),
                    readonly: ""
                  }, null, 8, ["label", "placeholder", "modelValue"])];
                }),
                _: 1
              })];
            }),
            _: 1
          }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_23__.Col), {
            span: "8"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_24__.Button), {
                type: "danger",
                size: "small",
                style: {
                  "margin-right": "10px",
                  "margin-top": "6px",
                  "float": "right"
                },
                onClick: deleteCalibrationInfoFn
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.toDisplayString)(_ctx.$t('LoadSettings.template[4]')), 1)];
                }),
                _: 1
              }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_24__.Button), {
                type: "primary",
                size: "small",
                style: {
                  "float": "right",
                  "margin-top": "6px",
                  "margin-right": "10px"
                },
                onClick: addCalibrationInfoFn
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.toDisplayString)(_ctx.$t('LoadSettings.template[5]')), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          })];
        }),
        _: 1
      })]), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_22__.Row), null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_23__.Col), {
            offset: "1",
            span: "22"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
              return [((0,vue__WEBPACK_IMPORTED_MODULE_13__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_13__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_13__.renderList)(addCalibrationInfo.value, function (item, index) {
                return (0,vue__WEBPACK_IMPORTED_MODULE_13__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createBlock)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.CellGroup), {
                  style: {
                    "margin-top": "10px"
                  },
                  key: index
                }, {
                  "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                    return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_20__.Cell), null, {
                      title: (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                        return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_25__.Checkbox), {
                          shape: "square",
                          modelValue: item.check,
                          "onUpdate:modelValue": function onUpdateModelValue($event) {
                            return item.check = $event;
                          }
                        }, {
                          "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                            return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.toDisplayString)(_ctx.$t('LoadSettings.template[6]')) + " " + (0,vue__WEBPACK_IMPORTED_MODULE_13__.toDisplayString)(index + 1), 1)];
                          }),
                          _: 2
                        }, 1032, ["modelValue", "onUpdate:modelValue"])];
                      }),
                      _: 2
                    }, 1024), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Field), {
                      type: "tel",
                      label: _ctx.$t('LoadSettings.template[7]'),
                      "label-width": "120",
                      placeholder: _ctx.$t('LoadSettings.templatePlaceholder[3]'),
                      "input-align": "right",
                      modelValue: item.value1,
                      "onUpdate:modelValue": function onUpdateModelValue($event) {
                        return item.value1 = $event;
                      }
                    }, {
                      button: (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                        return [_hoisted_5];
                      }),
                      _: 2
                    }, 1032, ["label", "placeholder", "modelValue", "onUpdate:modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.Field), {
                      type: "tel",
                      label: _ctx.$t('LoadSettings.template[8]'),
                      "label-width": "120",
                      placeholder: _ctx.$t('LoadSettings.templatePlaceholder[4]'),
                      "input-align": "right",
                      modelValue: item.value2,
                      "onUpdate:modelValue": function onUpdateModelValue($event) {
                        return item.value2 = $event;
                      }
                    }, {
                      button: (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
                        return [_hoisted_6];
                      }),
                      _: 2
                    }, 1032, ["label", "placeholder", "modelValue", "onUpdate:modelValue"])];
                  }),
                  _: 2
                }, 1024);
              }), 128))];
            }),
            _: 1
          })];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(vant__WEBPACK_IMPORTED_MODULE_26__.Popup), {
        round: "",
        show: showPicker.value,
        "onUpdate:show": _cache[5] || (_cache[5] = function ($event) {
          return showPicker.value = $event;
        }),
        position: "bottom"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_13__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)(_components_Alarm_AlarmPicker_vue__WEBPACK_IMPORTED_MODULE_15__["default"], {
            columns: columns.value,
            showPicker: showPicker.value,
            defaultIndex: defaultIndex.value,
            onConfirm: onConfirm,
            onCancel: _cache[4] || (_cache[4] = function ($event) {
              return showPicker.value = false;
            })
          }, null, 8, ["columns", "showPicker", "defaultIndex"])];
        }),
        _: 1
      }, 8, ["show"]), _hoisted_7, (0,vue__WEBPACK_IMPORTED_MODULE_13__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_13__.unref)(StickyBottom), {
        onBottomSubmit: BottomSubmit
      })], 64);
    };
  }
});

/***/ }),

/***/ "./src/views/phaseTwo/LoadSettings.vue":
/*!*********************************************!*\
  !*** ./src/views/phaseTwo/LoadSettings.vue ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _LoadSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LoadSettings.vue?vue&type=script&setup=true&lang=js */ "./src/views/phaseTwo/LoadSettings.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _LoadSettings_vue_vue_type_style_index_0_id_58cf7cea_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css */ "./src/views/phaseTwo/LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css");
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_vue_loader_17_0_0_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/_vue-loader@17.0.0@vue-loader/dist/exportHelper.js */ "./node_modules/_vue-loader@17.0.0@vue-loader/dist/exportHelper.js");



;


const __exports__ = /*#__PURE__*/(0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_vue_loader_17_0_0_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_LoadSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"], [['__scopeId',"data-v-58cf7cea"]])

/* harmony default export */ __webpack_exports__["default"] = (__exports__);

/***/ }),

/***/ "./src/views/phaseTwo/LoadSettings.vue?vue&type=script&setup=true&lang=js":
/*!********************************************************************************!*\
  !*** ./src/views/phaseTwo/LoadSettings.vue?vue&type=script&setup=true&lang=js ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* reexport safe */ _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_LoadSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]; }
/* harmony export */ });
/* harmony import */ var _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_LoadSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-41!../../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./LoadSettings.vue?vue&type=script&setup=true&lang=js */ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/LoadSettings.vue?vue&type=script&setup=true&lang=js");
 

/***/ }),

/***/ "./src/views/phaseTwo/LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css":
/*!*****************************************************************************************************!*\
  !*** ./src/views/phaseTwo/LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css ***!
  \*****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_clonedRuleSet_12_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_use_1_node_modules_vue_loader_17_0_0_vue_loader_dist_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_use_2_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_LoadSettings_vue_vue_type_style_index_0_id_58cf7cea_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!../../../node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!../../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css");


/***/ }),

/***/ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/phaseTwo/LoadSettings.vue?vue&type=style&index=0&id=58cf7cea&scoped=true&lang=css ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

}]);
//# sourceMappingURL=src_views_phaseTwo_LoadSettings_vue-src_components_Alarm_AlarmPicker_vue-src_components_ComCo-4f92f9.6f768252.js.map