(self["webpackChunkyunweibao_ad"] = self["webpackChunkyunweibao_ad"] || []).push([["src_views_CameraSettings_vue-src_components_stickyBottom_vue-src_components_tab_vue"],{

/***/ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraSettings.vue?vue&type=script&setup=true&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraSettings.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.for-each.js */ "./node_modules/core-js/modules/es.array.for-each.js");
/* harmony import */ var core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.date.to-string.js */ "./node_modules/core-js/modules/es.date.to-string.js");
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/web.timers.js */ "./node_modules/core-js/modules/web.timers.js");
/* harmony import */ var core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_timers_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/toast/function-call.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell-group/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/cell/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/radio-group/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/radio/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/grid/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/grid-item/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/image/index.mjs");
/* harmony import */ var vant__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! vant */ "./node_modules/_vant@3.6.2@vant/es/loading/index.mjs");
/* harmony import */ var _utlis_QueryStr__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/utlis/QueryStr */ "./src/utlis/QueryStr.js");
/* harmony import */ var _mixins_index_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../mixins/index.js */ "./src/mixins/index.js");














var _hoisted_1 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_12__.createTextVNode)("PAL");

var _hoisted_2 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_12__.createTextVNode)("NTSC");

var _hoisted_3 = {
  "class": "images"
};
 // Checkbox




/* harmony default export */ __webpack_exports__["default"] = ({
  __name: 'CameraSettings',
  setup: function setup(__props) {
    var _mixins = (0,_mixins_index_js__WEBPACK_IMPORTED_MODULE_14__["default"])(),
        t = _mixins.t,
        postAN = _mixins.postAN,
        TabHeaders = _mixins.TabHeaders,
        StickyBottom = _mixins.StickyBottom,
        useRoute = _mixins.useRoute,
        router = _mixins.router,
        callJSResult_Status = _mixins.callJSResult_Status;

    var route = useRoute();
    var guideRouter = route.query.guide; // 标题

    var navTitle = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)(t("cameraSettings.navTitle"));
    var imageNumber = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)(0);
    var guide = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)(false); // 是否是向导模式

    var imageInfo = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)([]);
    var successImageNum = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)(0);
    var checked = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)("1");
    var imageArr = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)([]);
    var nowCmd = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)(""); // 当前使用的指令

    var allCmd = (0,vue__WEBPACK_IMPORTED_MODULE_12__.ref)([]); // 所有的指令

    (0,vue__WEBPACK_IMPORTED_MODULE_12__.defineComponent)({
      name: "yunweibao-BSD"
    });

    var settingsImage = function settingsImage(item, index) {
      if (successImageNum.value == imageInfo.value.length) {
        router.push({
          path: "/CameraInfo",
          query: {
            e: item,
            allCmd: allCmd.value,
            nowCmd: nowCmd.value,
            index: index
          }
        });
      }
    }; // 查询


    var BottomSearch = function BottomSearch() {
      successImageNum.value = 0;
      (0,vant__WEBPACK_IMPORTED_MODULE_15__.Toast)(t("toast[0]"));
      postAN.ANSend(nowCmd.value);
      return false;
    }; // 保存


    var BottomSubmit = function BottomSubmit() {
      var cmds = (0,D_aEJ_apache_tomcat_9_0_54_webapps_yunweibao_ad_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(allCmd.value);

      console.log(cmds[1]);
      cmds[0] = checked.value;
      cmds.join(",");
      var data = []; // alert("2222")

      if (cmds.length > 1) {
        // console.warn(cmds);
        cmds.forEach(function (item, index) {
          if (index > 0) {
            var it = item.split(":")[0].split("#")[1];
            data.push(it);
          } else {
            data.push(item);
          }
        }); // console.log(data);
      }

      cmds = nowCmd.value + "," + data.toString(); // console.warn(cmds);

      postAN.ANsendSetting(cmds);
      return false;
    }; // -------------------------------------------------------------------
    // 安卓回调函数


    var callJSResult = function callJSResult(str) {
      var cmds = str.split(";")[0];
      console.warn(cmds);
      var cmdArr = cmds.split(",").splice(1); // alert(cmdArr);

      allCmd.value = cmdArr;
      imageNumber.value = cmdArr.length - 1;
      postAN.ANsendSelectPhoto(0);
      checked.value = cmdArr[0];
      imageInfo.value = cmdArr.slice(1);
    };

    var callJSResult_IMG = function callJSResult_IMG(state, data, index) {
      if (state == 0) {
        vant__WEBPACK_IMPORTED_MODULE_15__.Toast.success(state + successImageNum.value);
        return false;
      } else {
        if (imageNumber.value == successImageNum.value) {
          console.warn(imageArr.value.toString());
          return false;
        }

        imageArr.value[index] = data;
        successImageNum.value++;
        console.warn("发送通道" + successImageNum.value);

        if (successImageNum.value < imageInfo.value.length) {
          postAN.ANsendSelectPhoto(successImageNum.value);
          vant__WEBPACK_IMPORTED_MODULE_15__.Toast.clear();
        } // console.warn("获取到图片信息" + data);

      }
    }; // 向安卓发送指令


    var androidStatus_fn = function androidStatus_fn() {
      var param = "";

      if (guideRouter) {
        var guideIndex = sessionStorage.guideIndex;
        guide.value = true;
        var guideArr = JSON.parse(sessionStorage.guide);
        param = guideArr[guideIndex].split("@");
      } else {
        param = (0,_utlis_QueryStr__WEBPACK_IMPORTED_MODULE_13__.getQueryString)("param").split("@"); // 解析出指令
      } // var param = getQueryString("param").split("@"); // 解析出指令


      nowCmd.value = param[1];
      console.log(param[1]);
      postAN.ANSend(param[1]);
    };

    androidStatus_fn();

    var loadFn = function loadFn() {
      var timer;
      var num = 0;
      timer = setInterval(function () {
        num++;

        if (num == 10) {
          clearInterval(timer);
          vant__WEBPACK_IMPORTED_MODULE_15__.Toast.clear();
        }
      }, 1000);
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_12__.onMounted)(function () {
      window.callJSResult = callJSResult;
      window.callJSResult_Status = callJSResult_Status;
      window.callJSResult_IMG = callJSResult_IMG;
      loadFn();
      vant__WEBPACK_IMPORTED_MODULE_15__.Toast.loading({
        forbidClick: true,
        loadingType: "spinner",
        duration: 0
      });
    });
    return function (_ctx, _cache) {
      return (0,vue__WEBPACK_IMPORTED_MODULE_12__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_12__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(TabHeaders), {
        navTitle: navTitle.value,
        leftArrow: false
      }, null, 8, ["navTitle"]), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_16__.CellGroup), {
        inset: "",
        style: {
          "margin": "10px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_17__.Cell), {
            title: _ctx.$t('cameraSettings.title[0]')
          }, {
            "right-icon": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_18__.RadioGroup), {
                modelValue: checked.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
                  return checked.value = $event;
                })
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Radio), {
                    name: "0",
                    shape: "square",
                    style: {
                      "float": "left",
                      "margin-right": "10px"
                    },
                    "icon-size": "15px"
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
                      return [_hoisted_1];
                    }),
                    _: 1
                  }), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_19__.Radio), {
                    name: "1",
                    shape: "square",
                    "icon-size": "15px"
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
                      return [_hoisted_2];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }, 8, ["modelValue"])];
            }),
            _: 1
          }, 8, ["title"])];
        }),
        _: 1
      }), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_20__.Grid), {
        gutter: 2
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
          return [((0,vue__WEBPACK_IMPORTED_MODULE_12__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_12__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_12__.renderList)(imageInfo.value, function (item, index) {
            return (0,vue__WEBPACK_IMPORTED_MODULE_12__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createBlock)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_21__.GridItem), {
              key: index,
              onClick: function onClick($event) {
                return settingsImage(item, index);
              }
            }, {
              "default": (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
                return [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_22__.Image), {
                  height: "90",
                  width: "92",
                  src: imageArr.value[index]
                }, {
                  loading: (0,vue__WEBPACK_IMPORTED_MODULE_12__.withCtx)(function () {
                    return [(0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(vant__WEBPACK_IMPORTED_MODULE_23__.Loading), {
                      type: "spinner",
                      size: "20"
                    })];
                  }),
                  _: 2
                }, 1032, ["src"])];
              }),
              _: 2
            }, 1032, ["onClick"]);
          }), 128))];
        }),
        _: 1
      })]), (0,vue__WEBPACK_IMPORTED_MODULE_12__.createVNode)((0,vue__WEBPACK_IMPORTED_MODULE_12__.unref)(StickyBottom), {
        guide: guide.value,
        onBottomSearch: BottomSearch,
        onBottomSubmit: BottomSubmit,
        onBottomNext: _ctx.BottomNext
      }, null, 8, ["guide", "onBottomNext"])], 64);
    };
  }
});

/***/ }),

/***/ "./src/views/CameraSettings.vue":
/*!**************************************!*\
  !*** ./src/views/CameraSettings.vue ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CameraSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CameraSettings.vue?vue&type=script&setup=true&lang=js */ "./src/views/CameraSettings.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _CameraSettings_vue_vue_type_style_index_0_id_e538a288_lang_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css */ "./src/views/CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css");



;

const __exports__ = _CameraSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"];

/* harmony default export */ __webpack_exports__["default"] = (__exports__);

/***/ }),

/***/ "./src/views/CameraSettings.vue?vue&type=script&setup=true&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/CameraSettings.vue?vue&type=script&setup=true&lang=js ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* reexport safe */ _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_CameraSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]; }
/* harmony export */ });
/* harmony import */ var _node_modules_thread_loader_3_0_4_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_1_node_modules_babel_loader_lib_index_js_clonedRuleSet_41_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_CameraSettings_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-41!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./CameraSettings.vue?vue&type=script&setup=true&lang=js */ "./node_modules/_thread-loader@3.0.4@thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/babel-loader/lib/index.js??clonedRuleSet-41!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraSettings.vue?vue&type=script&setup=true&lang=js");
 

/***/ }),

/***/ "./src/views/CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css":
/*!**********************************************************************************!*\
  !*** ./src/views/CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_clonedRuleSet_12_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_use_1_node_modules_vue_loader_17_0_0_vue_loader_dist_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_use_2_node_modules_vue_loader_17_0_0_vue_loader_dist_index_js_ruleSet_0_use_0_CameraSettings_vue_vue_type_style_index_0_id_e538a288_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!../../node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css");


/***/ }),

/***/ "./node_modules/core-js/internals/array-for-each.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/internals/array-for-each.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var $forEach = (__webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").forEach);
var arrayMethodIsStrict = __webpack_require__(/*! ../internals/array-method-is-strict */ "./node_modules/core-js/internals/array-method-is-strict.js");

var STRICT_METHOD = arrayMethodIsStrict('forEach');

// `Array.prototype.forEach` method implementation
// https://tc39.es/ecma262/#sec-array.prototype.foreach
module.exports = !STRICT_METHOD ? function forEach(callbackfn /* , thisArg */) {
  return $forEach(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
// eslint-disable-next-line es-x/no-array-prototype-foreach -- safe
} : [].forEach;


/***/ }),

/***/ "./node_modules/core-js/internals/array-iteration.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/internals/array-iteration.js ***!
  \***********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/core-js/internals/indexed-object.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");
var arraySpeciesCreate = __webpack_require__(/*! ../internals/array-species-create */ "./node_modules/core-js/internals/array-species-create.js");

var push = uncurryThis([].push);

// `Array.prototype.{ forEach, map, filter, some, every, find, findIndex, filterReject }` methods implementation
var createMethod = function (TYPE) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var IS_FILTER_REJECT = TYPE == 7;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  return function ($this, callbackfn, that, specificCreate) {
    var O = toObject($this);
    var self = IndexedObject(O);
    var boundFunction = bind(callbackfn, that);
    var length = lengthOfArrayLike(self);
    var index = 0;
    var create = specificCreate || arraySpeciesCreate;
    var target = IS_MAP ? create($this, length) : IS_FILTER || IS_FILTER_REJECT ? create($this, 0) : undefined;
    var value, result;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      value = self[index];
      result = boundFunction(value, index, O);
      if (TYPE) {
        if (IS_MAP) target[index] = result; // map
        else if (result) switch (TYPE) {
          case 3: return true;              // some
          case 5: return value;             // find
          case 6: return index;             // findIndex
          case 2: push(target, value);      // filter
        } else switch (TYPE) {
          case 4: return false;             // every
          case 7: push(target, value);      // filterReject
        }
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : target;
  };
};

module.exports = {
  // `Array.prototype.forEach` method
  // https://tc39.es/ecma262/#sec-array.prototype.foreach
  forEach: createMethod(0),
  // `Array.prototype.map` method
  // https://tc39.es/ecma262/#sec-array.prototype.map
  map: createMethod(1),
  // `Array.prototype.filter` method
  // https://tc39.es/ecma262/#sec-array.prototype.filter
  filter: createMethod(2),
  // `Array.prototype.some` method
  // https://tc39.es/ecma262/#sec-array.prototype.some
  some: createMethod(3),
  // `Array.prototype.every` method
  // https://tc39.es/ecma262/#sec-array.prototype.every
  every: createMethod(4),
  // `Array.prototype.find` method
  // https://tc39.es/ecma262/#sec-array.prototype.find
  find: createMethod(5),
  // `Array.prototype.findIndex` method
  // https://tc39.es/ecma262/#sec-array.prototype.findIndex
  findIndex: createMethod(6),
  // `Array.prototype.filterReject` method
  // https://github.com/tc39/proposal-array-filtering
  filterReject: createMethod(7)
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.for-each.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.for-each.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var forEach = __webpack_require__(/*! ../internals/array-for-each */ "./node_modules/core-js/internals/array-for-each.js");

// `Array.prototype.forEach` method
// https://tc39.es/ecma262/#sec-array.prototype.foreach
// eslint-disable-next-line es-x/no-array-prototype-foreach -- safe
$({ target: 'Array', proto: true, forced: [].forEach != forEach }, {
  forEach: forEach
});


/***/ }),

/***/ "./node_modules/core-js/modules/web.dom-collections.for-each.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/web.dom-collections.for-each.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ../internals/global */ "./node_modules/core-js/internals/global.js");
var DOMIterables = __webpack_require__(/*! ../internals/dom-iterables */ "./node_modules/core-js/internals/dom-iterables.js");
var DOMTokenListPrototype = __webpack_require__(/*! ../internals/dom-token-list-prototype */ "./node_modules/core-js/internals/dom-token-list-prototype.js");
var forEach = __webpack_require__(/*! ../internals/array-for-each */ "./node_modules/core-js/internals/array-for-each.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");

var handlePrototype = function (CollectionPrototype) {
  // some Chrome versions have non-configurable methods on DOMTokenList
  if (CollectionPrototype && CollectionPrototype.forEach !== forEach) try {
    createNonEnumerableProperty(CollectionPrototype, 'forEach', forEach);
  } catch (error) {
    CollectionPrototype.forEach = forEach;
  }
};

for (var COLLECTION_NAME in DOMIterables) {
  if (DOMIterables[COLLECTION_NAME]) {
    handlePrototype(global[COLLECTION_NAME] && global[COLLECTION_NAME].prototype);
  }
}

handlePrototype(DOMTokenListPrototype);


/***/ }),

/***/ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/_vue-loader@17.0.0@vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/CameraSettings.vue?vue&type=style&index=0&id=e538a288&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/checkbox/Checker.mjs":
/*!***************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/checkbox/Checker.mjs ***!
  \***************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "checkerProps": function() { return /* binding */ checkerProps; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/basic.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/format.mjs");
/* harmony import */ var _icon_index_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/icon/index.mjs");




const checkerProps = {
  name: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.unknownProp,
  shape: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.makeStringProp)("round"),
  disabled: Boolean,
  iconSize: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.numericProp,
  modelValue: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.unknownProp,
  checkedColor: String,
  labelPosition: String,
  labelDisabled: Boolean
};
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  props: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.extend)({}, checkerProps, {
    bem: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.makeRequiredProp)(Function),
    role: String,
    parent: Object,
    checked: Boolean,
    bindGroup: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.truthProp
  }),
  emits: ["click", "toggle"],

  setup(props, {
    emit,
    slots
  }) {
    const iconRef = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)();

    const getParentProp = name => {
      if (props.parent && props.bindGroup) {
        return props.parent.props[name];
      }
    };

    const disabled = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => getParentProp("disabled") || props.disabled);
    const direction = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => getParentProp("direction"));
    const iconStyle = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const checkedColor = props.checkedColor || getParentProp("checkedColor");

      if (checkedColor && props.checked && !disabled.value) {
        return {
          borderColor: checkedColor,
          backgroundColor: checkedColor
        };
      }
    });

    const onClick = event => {
      const {
        target
      } = event;
      const icon = iconRef.value;
      const iconClicked = icon === target || (icon == null ? void 0 : icon.contains(target));

      if (!disabled.value && (iconClicked || !props.labelDisabled)) {
        emit("toggle");
      }

      emit("click", event);
    };

    const renderIcon = () => {
      const {
        bem,
        shape,
        checked
      } = props;
      const iconSize = props.iconSize || getParentProp("iconSize");
      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "ref": iconRef,
        "class": bem("icon", [shape, {
          disabled: disabled.value,
          checked
        }]),
        "style": {
          fontSize: (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_3__.addUnit)(iconSize)
        }
      }, [slots.icon ? slots.icon({
        checked,
        disabled: disabled.value
      }) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_icon_index_mjs__WEBPACK_IMPORTED_MODULE_4__.Icon, {
        "name": "success",
        "style": iconStyle.value
      }, null)]);
    };

    const renderLabel = () => {
      if (slots.default) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("span", {
          "class": props.bem("label", [props.labelPosition, {
            disabled: disabled.value
          }])
        }, [slots.default()]);
      }
    };

    return () => {
      const nodes = props.labelPosition === "left" ? [renderLabel(), renderIcon()] : [renderIcon(), renderLabel()];
      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "role": props.role,
        "class": props.bem([{
          disabled: disabled.value,
          "label-disabled": props.labelDisabled
        }, direction.value]),
        "tabindex": disabled.value ? void 0 : 0,
        "aria-checked": props.checked,
        "onClick": onClick
      }, [nodes]);
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/radio-group/RadioGroup.mjs":
/*!*********************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/radio-group/RadioGroup.mjs ***!
  \*********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RADIO_KEY": function() { return /* binding */ RADIO_KEY; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/props.mjs");
/* harmony import */ var _vant_use__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @vant/use */ "./node_modules/_@vant_use@1.4.2@@vant/use/dist/index.esm.mjs");




const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("radio-group");
const radioGroupProps = {
  disabled: Boolean,
  iconSize: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.numericProp,
  direction: String,
  modelValue: _utils_index_mjs__WEBPACK_IMPORTED_MODULE_2__.unknownProp,
  checkedColor: String
};
const RADIO_KEY = Symbol(name);
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  props: radioGroupProps,
  emits: ["change", "update:modelValue"],

  setup(props, {
    emit,
    slots
  }) {
    const {
      linkChildren
    } = (0,_vant_use__WEBPACK_IMPORTED_MODULE_3__.useChildren)(RADIO_KEY);

    const updateValue = value => emit("update:modelValue", value);

    (0,vue__WEBPACK_IMPORTED_MODULE_0__.watch)(() => props.modelValue, value => emit("change", value));
    linkChildren({
      props,
      updateValue
    });
    (0,_vant_use__WEBPACK_IMPORTED_MODULE_3__.useCustomFieldValue)(() => props.modelValue);
    return () => {
      var _a;

      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)("div", {
        "class": bem([props.direction]),
        "role": "radiogroup"
      }, [(_a = slots.default) == null ? void 0 : _a.call(slots)]);
    };
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/radio-group/index.mjs":
/*!****************************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/radio-group/index.mjs ***!
  \****************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RadioGroup": function() { return /* binding */ RadioGroup; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/with-install.mjs");
/* harmony import */ var _RadioGroup_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RadioGroup.mjs */ "./node_modules/_vant@3.6.2@vant/es/radio-group/RadioGroup.mjs");


const RadioGroup = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__.withInstall)(_RadioGroup_mjs__WEBPACK_IMPORTED_MODULE_1__["default"]);
var stdin_default = RadioGroup;


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/radio/Radio.mjs":
/*!**********************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/radio/Radio.mjs ***!
  \**********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/_vue@3.2.39@vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/create.mjs");
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/basic.mjs");
/* harmony import */ var _radio_group_RadioGroup_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../radio-group/RadioGroup.mjs */ "./node_modules/_vant@3.6.2@vant/es/radio-group/RadioGroup.mjs");
/* harmony import */ var _vant_use__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @vant/use */ "./node_modules/_@vant_use@1.4.2@@vant/use/dist/index.esm.mjs");
/* harmony import */ var _checkbox_Checker_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../checkbox/Checker.mjs */ "./node_modules/_vant@3.6.2@vant/es/checkbox/Checker.mjs");






const [name, bem] = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_1__.createNamespace)("radio");
var stdin_default = (0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  name,
  props: _checkbox_Checker_mjs__WEBPACK_IMPORTED_MODULE_2__.checkerProps,
  emits: ["update:modelValue"],

  setup(props, {
    emit,
    slots
  }) {
    const {
      parent
    } = (0,_vant_use__WEBPACK_IMPORTED_MODULE_3__.useParent)(_radio_group_RadioGroup_mjs__WEBPACK_IMPORTED_MODULE_4__.RADIO_KEY);

    const checked = () => {
      const value = parent ? parent.props.modelValue : props.modelValue;
      return value === props.name;
    };

    const toggle = () => {
      if (parent) {
        parent.updateValue(props.name);
      } else {
        emit("update:modelValue", props.name);
      }
    };

    return () => (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_checkbox_Checker_mjs__WEBPACK_IMPORTED_MODULE_2__["default"], (0,vue__WEBPACK_IMPORTED_MODULE_0__.mergeProps)({
      "bem": bem,
      "role": "radio",
      "parent": parent,
      "checked": checked(),
      "onToggle": toggle
    }, props), (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_5__.pick)(slots, ["default", "icon"]));
  }

});


/***/ }),

/***/ "./node_modules/_vant@3.6.2@vant/es/radio/index.mjs":
/*!**********************************************************!*\
  !*** ./node_modules/_vant@3.6.2@vant/es/radio/index.mjs ***!
  \**********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Radio": function() { return /* binding */ Radio; },
/* harmony export */   "default": function() { return /* binding */ stdin_default; }
/* harmony export */ });
/* harmony import */ var _utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/index.mjs */ "./node_modules/_vant@3.6.2@vant/es/utils/with-install.mjs");
/* harmony import */ var _Radio_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Radio.mjs */ "./node_modules/_vant@3.6.2@vant/es/radio/Radio.mjs");


const Radio = (0,_utils_index_mjs__WEBPACK_IMPORTED_MODULE_0__.withInstall)(_Radio_mjs__WEBPACK_IMPORTED_MODULE_1__["default"]);
var stdin_default = Radio;


/***/ })

}]);
//# sourceMappingURL=src_views_CameraSettings_vue-src_components_stickyBottom_vue-src_components_tab_vue.f60416e6.js.map